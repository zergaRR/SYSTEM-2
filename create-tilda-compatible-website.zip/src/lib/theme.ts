// Общий CSS для сайта, админки, экспорта в GitHub и кода для Тильды.
// Все правила привязаны к классу .acad-root, чтобы не конфликтовать со стилями Тильды.
export const SITE_CSS = `
@import url("https://fonts.googleapis.com/css2?family=Unbounded:wght@500;700;900&family=Golos+Text:wght@400;500;600;700;800&display=swap");

.acad-root, .acad-root *, .acad-root *::before, .acad-root *::after { box-sizing: border-box; }
.acad-root {
  --bg: #F5F2EB; --ink: #0E1019; --blue: #293BFF; --lime: #D1FF38; --white: #ffffff;
  --muted: #5B5E6C; --line: #000000; --danger: #E5484D;
  margin: 0; min-height: 100vh; background: var(--bg); color: var(--ink);
  font-family: "Golos Text", -apple-system, BlinkMacSystemFont, sans-serif;
  font-size: 17px; line-height: 1.55; -webkit-font-smoothing: antialiased;
}
.acad-root h1, .acad-root h2, .acad-root h3, .acad-root h4, .acad-root p { margin: 0; }
.acad-root h1, .acad-root h2, .acad-root h3, .acad-root .display {
  font-family: "Unbounded", sans-serif; font-weight: 900; letter-spacing: -0.01em; line-height: 1.12;
}
.acad-root a { color: inherit; }
.acad-root img, .acad-root video, .acad-root iframe { max-width: 100%; }
.acad-root .wrap { max-width: 1100px; margin: 0 auto; padding: 0 20px; }
.acad-root .wrap-narrow { max-width: 820px; margin: 0 auto; padding: 0 20px; }
.acad-root .muted { color: var(--muted); }
.acad-root .hidden { display: none !important; }

/* Шапка */
.acad-root .topbar { background: var(--white); border-bottom: 3px solid var(--line); position: sticky; top: 0; z-index: 20; }
.acad-root .topbar-inner { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 12px 20px; max-width: 1100px; margin: 0 auto; flex-wrap: wrap; }
.acad-root .logo { font-family: "Unbounded", sans-serif; font-weight: 900; text-decoration: none; font-size: 18px; background: var(--lime); border: 3px solid var(--line); box-shadow: 3px 3px 0 var(--line); padding: 4px 10px; }
.acad-root .nav { display: flex; gap: 8px; flex-wrap: wrap; }
.acad-root .nav a { text-decoration: none; font-weight: 700; font-size: 14px; padding: 7px 12px; border: 3px solid transparent; }
.acad-root .nav a:hover, .acad-root .nav a.active { border-color: var(--line); background: var(--bg); }

/* Кнопки и блоки */
.acad-root .btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; font-family: "Golos Text", sans-serif; font-weight: 800; font-size: 15px; color: var(--ink); background: var(--white); border: 3px solid var(--line); box-shadow: 4px 4px 0 var(--line); padding: 10px 18px; text-decoration: none; cursor: pointer; transition: all .15s; }
.acad-root .btn:hover { box-shadow: 1px 1px 0 var(--line); transform: translate(3px, 3px); }
.acad-root .btn:disabled { opacity: .5; cursor: not-allowed; transform: none; box-shadow: 4px 4px 0 var(--line); }
.acad-root .btn-primary { background: var(--blue); color: var(--white); }
.acad-root .btn-lime { background: var(--lime); }
.acad-root .btn-danger { background: var(--danger); color: var(--white); }
.acad-root .btn-sm { font-size: 13px; padding: 6px 10px; box-shadow: 2px 2px 0 var(--line); }
.acad-root .btn-sm:hover { box-shadow: 0 0 0 var(--line); transform: translate(2px, 2px); }
.acad-root .card { background: var(--white); border: 3px solid var(--line); box-shadow: 6px 6px 0 var(--line); padding: 22px; }
.acad-root .card-link { display: block; text-decoration: none; background: var(--white); border: 3px solid var(--line); box-shadow: 5px 5px 0 var(--line); padding: 20px; transition: all .15s; }
.acad-root .card-link:hover { box-shadow: 1px 1px 0 var(--line); transform: translate(4px, 4px); }
.acad-root .tag { display: inline-block; font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: .04em; background: var(--lime); border: 2px solid var(--line); padding: 2px 8px; }
.acad-root .tag-blue { background: var(--blue); color: var(--white); }
.acad-root .tag-done { background: var(--lime); }
.acad-root .tag-draft { background: #ffd0d0; }

/* Главная */
.acad-root .hero { padding: 56px 0 36px; }
.acad-root .hero h1 { font-size: clamp(30px, 6vw, 56px); max-width: 16ch; }
.acad-root .hero .sub { font-size: 19px; max-width: 58ch; margin-top: 16px; color: var(--muted); }
.acad-root .hero .badge { display: inline-block; background: var(--lime); border: 3px solid var(--line); box-shadow: 4px 4px 0 var(--line); padding: 4px 12px; font-weight: 800; margin-bottom: 18px; transform: rotate(-1deg); }
.acad-root .progress-card { margin-top: 32px; display: flex; flex-wrap: wrap; gap: 18px; align-items: center; justify-content: space-between; }
.acad-root .bar { height: 14px; border: 3px solid var(--line); background: var(--white); min-width: 200px; flex: 1; }
.acad-root .bar > span { display: block; height: 100%; width: 0; background: var(--blue); transition: width .3s; }
.acad-root .tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 22px; margin: 36px 0 56px; }
.acad-root .tile-title { font-family: "Unbounded", sans-serif; font-weight: 900; font-size: 20px; margin-bottom: 6px; }

/* Списки уроков */
.acad-root .page-head { padding: 40px 0 24px; }
.acad-root .page-head h1 { font-size: clamp(28px, 5vw, 44px); }
.acad-root .page-head p { margin-top: 12px; color: var(--muted); max-width: 62ch; }
.acad-root .lesson-list { display: grid; gap: 18px; margin-bottom: 64px; }
.acad-root .lesson-card { display: grid; grid-template-columns: 74px 1fr; gap: 16px; align-items: start; text-decoration: none; background: var(--white); border: 3px solid var(--line); box-shadow: 5px 5px 0 var(--line); padding: 18px; transition: all .15s; }
.acad-root .lesson-card:hover { box-shadow: 1px 1px 0 var(--line); transform: translate(4px, 4px); }
.acad-root .step-no { font-family: "Unbounded", sans-serif; font-weight: 900; font-size: 22px; text-align: center; background: var(--bg); border: 3px solid var(--line); padding: 10px 0; }
.acad-root .lesson-card h3 { font-size: 19px; }
.acad-root .lesson-card p { color: var(--muted); margin-top: 6px; }
.acad-root .lesson-card.is-done .step-no { background: var(--lime); }
.acad-root .lesson-card .meta { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; align-items: center; }

/* Урок */
.acad-root .lesson-head { padding: 36px 0 20px; }
.acad-root .lesson-head h1 { font-size: clamp(26px, 4.5vw, 40px); margin-top: 12px; }
.acad-root .lesson-head p { margin-top: 12px; font-size: 18px; color: var(--muted); }
.acad-root .blocks { display: grid; gap: 26px; margin: 24px 0 40px; }
.acad-root .block { background: var(--white); border: 3px solid var(--line); box-shadow: 6px 6px 0 var(--line); padding: 20px; }
.acad-root .block h2 { font-size: 19px; margin-bottom: 14px; }
.acad-root .block .text p + p { margin-top: 12px; }
.acad-root .block .text h3 { font-size: 20px; margin: 18px 0 8px; }
.acad-root .block .text ul, .acad-root .block .text ol, .acad-root .article-body ul, .acad-root .article-body ol { padding-left: 24px; margin: 10px 0; }
.acad-root .block .text blockquote, .acad-root .article-body blockquote { margin: 14px 0; padding: 10px 16px; border-left: 6px solid var(--blue); background: var(--bg); }
.acad-root .block .text code, .acad-root .article-body code { font-family: ui-monospace, Menlo, monospace; background: var(--bg); border: 2px solid var(--line); padding: 0 4px; }
.acad-root .media-frame { width: 100%; aspect-ratio: 16 / 9; border: 3px solid var(--line); background: #000; }
.acad-root .media-frame iframe, .acad-root .media-frame video { width: 100%; height: 100%; display: block; }
.acad-root .media-img { display: block; width: 100%; height: auto; border: 3px solid var(--line); }
.acad-root audio { width: 100%; }
.acad-root .caption { margin-top: 12px; color: var(--muted); font-size: 15px; }
.acad-root .pager { display: flex; justify-content: space-between; gap: 12px; flex-wrap: wrap; padding: 8px 0 60px; }

/* Статьи */
.acad-root .article-cover { width: 100%; height: auto; max-height: 420px; object-fit: cover; border: 3px solid var(--line); margin: 18px 0 26px; }
.acad-root .article-body { font-size: 18px; }
.acad-root .article-body h2 { font-size: 26px; margin: 28px 0 10px; }
.acad-root .article-body h3 { font-size: 21px; margin: 22px 0 8px; }
.acad-root .article-body p + p { margin-top: 14px; }
.acad-root .article-list { display: grid; gap: 22px; margin-bottom: 64px; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); }
.acad-root .article-card { display: flex; flex-direction: column; text-decoration: none; background: var(--white); border: 3px solid var(--line); box-shadow: 5px 5px 0 var(--line); transition: all .15s; overflow: hidden; }
.acad-root .article-card:hover { box-shadow: 1px 1px 0 var(--line); transform: translate(4px, 4px); }
.acad-root .article-card .thumb { width: 100%; height: 170px; object-fit: cover; border-bottom: 3px solid var(--line); background: var(--lime); }
.acad-root .article-card .thumb-empty { height: 170px; border-bottom: 3px solid var(--line); background: var(--blue); }
.acad-root .article-card .info { padding: 16px; }
.acad-root .article-card h3 { font-size: 18px; }
.acad-root .article-card p { color: var(--muted); margin-top: 6px; font-size: 15px; }

/* Медиатека */
.acad-root .filters { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 26px; }
.acad-root .filter-btn { font-family: "Golos Text", sans-serif; font-weight: 800; font-size: 14px; padding: 8px 14px; border: 3px solid var(--line); background: var(--white); box-shadow: 2px 2px 0 var(--line); cursor: pointer; }
.acad-root .filter-btn.is-active { background: var(--ink); color: var(--white); }
.acad-root .media-grid { display: grid; gap: 22px; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); margin-bottom: 64px; }
.acad-root .media-card { background: var(--white); border: 3px solid var(--line); box-shadow: 5px 5px 0 var(--line); display: flex; flex-direction: column; }
.acad-root .media-thumb { position: relative; aspect-ratio: 16 / 10; border-bottom: 3px solid var(--line); background: var(--blue); color: var(--white); display: flex; align-items: center; justify-content: center; overflow: hidden; cursor: pointer; border-left: 0; border-right: 0; border-top: 0; width: 100%; padding: 0; }
.acad-root .media-thumb img { width: 100%; height: 100%; object-fit: cover; }
.acad-root .media-thumb .play { font-family: "Unbounded", sans-serif; font-size: 34px; }
.acad-root .media-thumb .kind { position: absolute; top: 10px; left: 10px; background: var(--white); color: var(--ink); border: 2px solid var(--line); font-size: 12px; font-weight: 800; padding: 2px 8px; }
.acad-root .media-info { padding: 14px; }
.acad-root .media-info h3 { font-size: 16px; }
.acad-root .media-info a { font-size: 14px; color: var(--blue); font-weight: 700; }

/* Модальное окно */
.acad-root dialog.viewer { width: min(860px, 94vw); border: 3px solid var(--line); box-shadow: 8px 8px 0 var(--line); padding: 20px; background: var(--white); color: var(--ink); }
.acad-root dialog.viewer::backdrop { background: rgba(14, 16, 25, .7); }
.acad-root .viewer-head { display: flex; justify-content: space-between; gap: 12px; align-items: start; margin-bottom: 14px; }
.acad-root .viewer-head h3 { font-size: 18px; }

/* Подвал */
.acad-root footer.foot { border-top: 3px solid var(--line); background: var(--white); padding: 22px 0; font-size: 14px; color: var(--muted); }

/* Админка */
.acad-root .admin-wrap { max-width: 1180px; margin: 0 auto; padding: 28px 20px 80px; }
.acad-root .admin-title { font-size: clamp(24px, 4vw, 34px); margin-bottom: 8px; }
.acad-root .admin-sub { color: var(--muted); margin-bottom: 26px; }
.acad-root .admin-grid { display: grid; grid-template-columns: 1fr; gap: 22px; }
@media (min-width: 900px) { .acad-root .admin-grid.two { grid-template-columns: 1fr 1fr; } }
.acad-root .field { display: grid; gap: 6px; margin-bottom: 16px; }
.acad-root .field label, .acad-root .label { font-weight: 800; font-size: 14px; }
.acad-root .hint { font-size: 13px; color: var(--muted); }
.acad-root input[type="text"], .acad-root input[type="password"], .acad-root input[type="url"], .acad-root input[type="number"], .acad-root select, .acad-root textarea {
  font: inherit; color: var(--ink); background: var(--white); border: 3px solid var(--line); padding: 10px 12px; width: 100%; border-radius: 0;
}
.acad-root textarea { min-height: 120px; resize: vertical; }
.acad-root input[type="file"] { font: inherit; background: var(--white); border: 3px dashed var(--line); padding: 12px; width: 100%; }
.acad-root .check { display: flex; gap: 10px; align-items: center; font-weight: 700; }
.acad-root .check input { width: 20px; height: 20px; accent-color: var(--blue); }
.acad-root .row { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
.acad-root .table { width: 100%; border-collapse: collapse; background: var(--white); border: 3px solid var(--line); box-shadow: 5px 5px 0 var(--line); }
.acad-root .table th, .acad-root .table td { text-align: left; padding: 12px; border-bottom: 2px solid #e5e1d6; vertical-align: middle; font-size: 15px; }
.acad-root .table th { font-size: 13px; text-transform: uppercase; letter-spacing: .04em; background: var(--bg); }
.acad-root .block-item { background: var(--white); border: 3px solid var(--line); box-shadow: 4px 4px 0 var(--line); padding: 16px; display: grid; gap: 12px; }
.acad-root .notice { border: 3px solid var(--line); background: var(--lime); padding: 12px 16px; font-weight: 700; margin-bottom: 18px; }
.acad-root .notice.error { background: #ffd0d0; }
.acad-root .codebox { width: 100%; min-height: 260px; font-family: ui-monospace, Menlo, monospace; font-size: 13px; }
.acad-root .steps { counter-reset: st; display: grid; gap: 14px; }
.acad-root .steps > div { background: var(--white); border: 3px solid var(--line); padding: 16px 18px 16px 62px; position: relative; }
.acad-root .steps > div::before { counter-increment: st; content: counter(st); position: absolute; left: 16px; top: 14px; font-family: "Unbounded", sans-serif; font-weight: 900; font-size: 22px; background: var(--lime); border: 3px solid var(--line); width: 36px; height: 36px; display: grid; place-items: center; }
.acad-root .steps h3 { font-size: 17px; margin-bottom: 6px; }
.acad-root .steps p + p { margin-top: 6px; }
.acad-root .login-box { max-width: 420px; margin: 60px auto; }

/* Tilda: одностраничный режим (разделы переключаются по хэшу) */
.acad-spa [data-view] { display: none; }
.acad-spa [data-view].is-active { display: block; }
.acad-spa .acad-spa-top { display: none; }

@media (max-width: 640px) {
  .acad-root { font-size: 16px; }
  .acad-root .lesson-card { grid-template-columns: 56px 1fr; }
  .acad-root .btn { font-size: 14px; }
}
`;
