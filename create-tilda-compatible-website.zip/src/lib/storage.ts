import { randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";
import { db } from "@/db";
import { mediaFiles } from "@/db/schema";
import { eq } from "drizzle-orm";

export type MediaKind = "image" | "video" | "audio";

// Папка для загруженных файлов (создаётся автоматически при первой загрузке).
export const UPLOAD_DIR = path.join(process.cwd(), "uploads");

export const UPLOAD_LIMIT_MB: Record<MediaKind, number> = {
  image: 15,
  audio: 80,
  video: 200,
};

const TYPES: Record<string, { kind: MediaKind; ext: string }> = {
  "image/jpeg": { kind: "image", ext: "jpg" },
  "image/png": { kind: "image", ext: "png" },
  "image/webp": { kind: "image", ext: "webp" },
  "image/gif": { kind: "image", ext: "gif" },
  "video/mp4": { kind: "video", ext: "mp4" },
  "video/webm": { kind: "video", ext: "webm" },
  "video/quicktime": { kind: "video", ext: "mov" },
  "audio/mpeg": { kind: "audio", ext: "mp3" },
  "audio/mp4": { kind: "audio", ext: "m4a" },
  "audio/x-m4a": { kind: "audio", ext: "m4a" },
  "audio/wav": { kind: "audio", ext: "wav" },
  "audio/x-wav": { kind: "audio", ext: "wav" },
  "audio/ogg": { kind: "audio", ext: "ogg" },
};

const BY_EXT: Record<string, string> = {
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  png: "image/png",
  webp: "image/webp",
  gif: "image/gif",
  mp4: "video/mp4",
  webm: "video/webm",
  mov: "video/quicktime",
  mp3: "audio/mpeg",
  m4a: "audio/mp4",
  wav: "audio/wav",
  ogg: "audio/ogg",
};

export function kindFromMime(mime: string): MediaKind | null {
  if (mime.startsWith("image/")) return "image";
  if (mime.startsWith("video/")) return "video";
  if (mime.startsWith("audio/")) return "audio";
  return null;
}

function resolveType(file: File): { mime: string; kind: MediaKind; ext: string } | null {
  const byMime = TYPES[file.type];
  if (byMime) return { mime: file.type, ...byMime };
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  const mime = BY_EXT[ext];
  if (!mime) return null;
  const kind = kindFromMime(mime);
  if (!kind) return null;
  return { mime, kind, ext: ext === "jpeg" ? "jpg" : ext };
}

export async function saveUpload(file: File, allowed: MediaKind[]) {
  const resolved = resolveType(file);
  if (!resolved) {
    throw new Error(
      "Этот формат не поддерживается. Фото: JPG, PNG, WEBP, GIF. Видео: MP4, WEBM, MOV. Аудио: MP3, M4A, WAV, OGG.",
    );
  }
  if (!allowed.includes(resolved.kind)) {
    throw new Error("Тип файла не подходит для этого места. Выберите файл другого типа.");
  }
  const limit = UPLOAD_LIMIT_MB[resolved.kind];
  if (file.size > limit * 1024 * 1024) {
    throw new Error(
      `Файл слишком большой (максимум ${limit} МБ). Для больших видео используйте ссылку на YouTube, RuTube или VK.`,
    );
  }
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  const storedName = `${randomUUID()}.${resolved.ext}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(path.join(UPLOAD_DIR, storedName), buffer);
  const [row] = await db
    .insert(mediaFiles)
    .values({
      originalName: file.name.slice(0, 200),
      mimeType: resolved.mime,
      sizeBytes: buffer.length,
      storagePath: storedName,
    })
    .returning();
  return row;
}

export function storedFilePath(storedName: string): string {
  return path.join(UPLOAD_DIR, path.basename(storedName));
}

export async function removeStoredFile(storedName: string): Promise<void> {
  await fs.rm(storedFilePath(storedName), { force: true });
}

export async function getFileRow(id: number) {
  const [row] = await db.select().from(mediaFiles).where(eq(mediaFiles.id, id));
  return row ?? null;
}
