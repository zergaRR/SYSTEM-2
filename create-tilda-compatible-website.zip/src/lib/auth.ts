import { randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { eq, lt } from "drizzle-orm";
import { db } from "@/db";
import { adminSessions } from "@/db/schema";
import { ensureBootstrap, getPasswordHash } from "@/lib/content";
import { verifyPassword } from "@/lib/password";

export const ADMIN_COOKIE = "academy_admin";
const SESSION_DAYS = 30;

export async function checkPassword(password: string): Promise<boolean> {
  const stored = await getPasswordHash();
  return !!stored && verifyPassword(password, stored);
}

export async function createSession(): Promise<{ token: string; expires: Date }> {
  await ensureBootstrap();
  const token = randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.delete(adminSessions).where(lt(adminSessions.expiresAt, new Date()));
  await db.insert(adminSessions).values({ token, expiresAt: expires });
  return { token, expires };
}

export async function isValidToken(token: string | undefined | null): Promise<boolean> {
  if (!token) return false;
  const [row] = await db.select().from(adminSessions).where(eq(adminSessions.token, token));
  return !!row && row.expiresAt.getTime() > Date.now();
}

// Проверка для страниц (server components).
export async function isAdminPage(): Promise<boolean> {
  const store = await cookies();
  return isValidToken(store.get(ADMIN_COOKIE)?.value);
}

export async function destroySession(token: string | undefined | null): Promise<void> {
  if (token) await db.delete(adminSessions).where(eq(adminSessions.token, token));
}

// Для API: возвращает ответ 401, если администратор не вошёл в систему.
export async function requireAdmin(): Promise<Response | null> {
  if (await isAdminPage()) return null;
  return Response.json({ error: "Войдите в админку, чтобы продолжить." }, { status: 401 });
}

export function isSecureRequest(request: Request): boolean {
  return (
    request.headers.get("x-forwarded-proto") === "https" ||
    new URL(request.url).protocol === "https:"
  );
}
