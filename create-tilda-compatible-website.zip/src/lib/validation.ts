import type { BlockInput } from "@/lib/content";

export const BLOCK_KINDS = ["video", "audio", "image", "text"] as const;

type Parsed<T> = { ok: true; value: T } | { ok: false; error: string };

function text(value: unknown, max: number): string {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function isHttpUrl(value: string): boolean {
  return /^https?:\/\/\S+$/i.test(value);
}

// Проверка данных блока. В режиме create обязательны тип и содержимое, в update — только переданные поля.
export function parseBlockBody(
  body: Record<string, unknown>,
  mode: "create" | "update",
): Parsed<Partial<BlockInput>> {
  const value: Partial<BlockInput> = {};
  const has = (key: string) => mode === "create" || key in body;

  if (has("kind")) {
    if (typeof body.kind !== "string" || !(BLOCK_KINDS as readonly string[]).includes(body.kind)) {
      return { ok: false, error: "Выберите тип блока." };
    }
    value.kind = body.kind;
  }
  if (has("title")) value.title = text(body.title, 200);
  if (has("body")) value.body = typeof body.body === "string" ? body.body.slice(0, 20000) : "";
  if (has("externalUrl")) value.externalUrl = text(body.externalUrl, 2000);
  if (has("fileId")) {
    value.fileId =
      typeof body.fileId === "number" && Number.isInteger(body.fileId) ? body.fileId : null;
  }

  const kind = value.kind;
  if (kind === "text") {
    if (mode === "create" && !(value.body ?? "").trim()) {
      return { ok: false, error: "Напишите текст блока." };
    }
    value.fileId = null;
    value.externalUrl = "";
  } else if (kind) {
    const hasFile = value.fileId !== null && value.fileId !== undefined;
    const link = value.externalUrl ?? "";
    if (link && !isHttpUrl(link)) {
      return { ok: false, error: "Ссылка должна начинаться с https://" };
    }
    if (mode === "create" && !hasFile && !link) {
      return { ok: false, error: "Загрузите файл или вставьте ссылку." };
    }
    if (hasFile) value.externalUrl = "";
  }
  return { ok: true, value };
}
