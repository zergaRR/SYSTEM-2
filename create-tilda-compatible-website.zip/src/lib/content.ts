import { and, asc, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  articles,
  lessonBlocks,
  lessons,
  mediaFiles,
  siteSettings,
} from "@/db/schema";
import { DEFAULT_ADMIN_PASSWORD, hashPassword } from "@/lib/password";
import { removeStoredFile } from "@/lib/storage";

export type FileRow = typeof mediaFiles.$inferSelect;
export type LessonRow = typeof lessons.$inferSelect;
export type BlockRow = typeof lessonBlocks.$inferSelect;
export type ArticleRow = typeof articles.$inferSelect;
export type BlockWithFile = BlockRow & { file: FileRow | null };
export type LessonWithBlocks = LessonRow & { blocks: BlockWithFile[] };
export type ArticleWithCover = ArticleRow & { cover: FileRow | null };

const DEFAULT_SETTINGS: Record<string, string> = {
  site_title: "Академия команды",
  site_subtitle:
    "Пошаговое обучение партнёров: видео, аудио, схемы и статьи в одном месте. Проходите уроки по порядку и отмечайте пройденное.",
  about_title: "О наставнике",
  about_text:
    "Здесь расскажите о себе: как вы пришли в команду, чему научились и чем готовы помочь новичкам.\n\nЭто пример текста. Измените его в разделе «Настройки» админки.",
  public_base_url: "",
  about_photo_file_id: "",
};

const DEMO_LESSONS: { title: string; summary: string; text: string }[] = [
  {
    title: "Добро пожаловать в команду",
    summary: "Как устроено обучение и с чего начать.",
    text:
      "Это пример урока. Замените заголовок и текст, а видео, фото и аудио добавьте блоками.\n\nЧтобы изменить урок, откройте админку, раздел «Уроки» и нажмите «Открыть».",
  },
  {
    title: "Первые 48 часов",
    summary: "Что важно сделать в первые два дня.",
    text:
      "Не пытайтесь выучить всё сразу. Пройдите уроки по порядку и отметьте каждый как пройденный.\n\n- Познакомьтесь с наставником\n- Изучите продукт\n- Составьте список знакомых для первого общения",
  },
  {
    title: "Знакомство с продуктом",
    summary: "Что мы рекомендуем и почему.",
    text:
      "Говорите о своём опыте, а не о характеристиках. Так рассказ становится понятным и живым.\n\n**Главное правило:** сначала опыт, потом предложение.",
  },
  {
    title: "Первое сообщение",
    summary: "Как написать первое сообщение знакомому.",
    text:
      "Короткое сообщение с личным обращением работает лучше длинного текста.\n\n1. Поздоровайтесь по имени\n2. Напомните, как вы знакомы\n3. Задайте один простой вопрос",
  },
  {
    title: "Работа с возражениями",
    summary: "Принять, уточнить, ответить.",
    text:
      "> Не спорьте с возражением. Сначала признайте его, затем уточните причину.\n\nСхема: принять — уточнить — ответить.",
  },
  {
    title: "Рост команды",
    summary: "Как помогать новичкам расти самостоятельно.",
    text:
      "Лучший способ растить команду — учить других тому, чему научились сами.\n\nПроводите первую встречу с новичком по плану и фиксируйте результат.",
  },
];

const DEMO_ARTICLES: { title: string; excerpt: string; body: string }[] = [
  {
    title: "Как провести первую встречу с новичком",
    excerpt: "Пошаговый план первой встречи: цели, вопросы и итог.",
    body:
      "## Цель встречи\n\nПоймите, чего человек ждёт от команды, и договоритесь о следующем шаге.\n\n## План\n\n1. Знакомство и история пути\n2. Вопросы о целях\n3. Знакомство с обучением\n4. Договорённость о следующей встрече\n\n> Это пример статьи. Замените текст в админке.",
  },
  {
    title: "Памятка наставника",
    excerpt: "Короткий чек-лист для ежедневной работы с командой.",
    body:
      "## Каждый день\n\n- Ответьте новичкам в течение дня\n- Отметьте прогресс в обучении\n- Поделитесь одним полезным опытом\n\n## Каждую неделю\n\n- Проведите встречу с каждым новичком\n- Обсудите цели на следующую неделю",
  },
];

let bootstrapPromise: Promise<void> | null = null;

// Однократная подготовка: настройки по умолчанию, пароль администратора и примеры.
export function ensureBootstrap(): Promise<void> {
  if (!bootstrapPromise) {
    bootstrapPromise = runBootstrap().catch((error) => {
      bootstrapPromise = null;
      throw error;
    });
  }
  return bootstrapPromise;
}

async function runBootstrap(): Promise<void> {
  const existing = await db.select({ key: siteSettings.key }).from(siteSettings);
  const keys = new Set(existing.map((row) => row.key));

  if (!keys.has("admin_password_hash")) {
    await db
      .insert(siteSettings)
      .values({ key: "admin_password_hash", value: hashPassword(DEFAULT_ADMIN_PASSWORD) })
      .onConflictDoNothing();
  }
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    if (!keys.has(key)) {
      await db.insert(siteSettings).values({ key, value }).onConflictDoNothing();
    }
  }
  if (!keys.has("demo_seeded")) {
    await seedDemo();
    await db
      .insert(siteSettings)
      .values({ key: "demo_seeded", value: "1" })
      .onConflictDoNothing();
  }
}

async function seedDemo(): Promise<void> {
  const existingLessons = await db.select({ id: lessons.id }).from(lessons).limit(1);
  if (existingLessons.length === 0) {
    for (let i = 0; i < DEMO_LESSONS.length; i++) {
      const item = DEMO_LESSONS[i];
      const [lesson] = await db
        .insert(lessons)
        .values({ title: item.title, summary: item.summary, position: i + 1 })
        .returning();
      await db.insert(lessonBlocks).values({
        lessonId: lesson.id,
        kind: "text",
        title: "Материал урока",
        body: item.text,
        position: 1,
      });
    }
  }
  const existingArticles = await db.select({ id: articles.id }).from(articles).limit(1);
  if (existingArticles.length === 0) {
    await db.insert(articles).values(
      DEMO_ARTICLES.map((item) => ({ title: item.title, excerpt: item.excerpt, body: item.body })),
    );
  }
}

async function attachBlocks(rows: LessonRow[]): Promise<LessonWithBlocks[]> {
  if (rows.length === 0) return [];
  const blockRows = await db
    .select()
    .from(lessonBlocks)
    .where(inArray(lessonBlocks.lessonId, rows.map((r) => r.id)))
    .orderBy(asc(lessonBlocks.position), asc(lessonBlocks.id));
  const fileIds = [
    ...new Set(blockRows.map((b) => b.fileId).filter((x): x is number => x !== null)),
  ];
  const files = fileIds.length
    ? await db.select().from(mediaFiles).where(inArray(mediaFiles.id, fileIds))
    : [];
  const fileMap = new Map(files.map((f) => [f.id, f] as const));
  return rows.map((lesson) => ({
    ...lesson,
    blocks: blockRows
      .filter((b) => b.lessonId === lesson.id)
      .map((b) => ({ ...b, file: b.fileId ? fileMap.get(b.fileId) ?? null : null })),
  }));
}

export async function listLessons(opts: { publishedOnly: boolean }): Promise<LessonWithBlocks[]> {
  await ensureBootstrap();
  const rows = await db
    .select()
    .from(lessons)
    .where(opts.publishedOnly ? eq(lessons.isPublished, true) : undefined)
    .orderBy(asc(lessons.position), asc(lessons.id));
  return attachBlocks(rows);
}

export async function getLesson(
  id: number,
  opts: { publishedOnly: boolean },
): Promise<LessonWithBlocks | null> {
  await ensureBootstrap();
  const [row] = await db
    .select()
    .from(lessons)
    .where(and(eq(lessons.id, id), opts.publishedOnly ? eq(lessons.isPublished, true) : undefined));
  if (!row) return null;
  const [withBlocks] = await attachBlocks([row]);
  return withBlocks ?? null;
}

async function attachCovers(rows: ArticleRow[]): Promise<ArticleWithCover[]> {
  const ids = [
    ...new Set(rows.map((r) => r.coverFileId).filter((x): x is number => x !== null)),
  ];
  const files = ids.length
    ? await db.select().from(mediaFiles).where(inArray(mediaFiles.id, ids))
    : [];
  const fileMap = new Map(files.map((f) => [f.id, f] as const));
  return rows.map((a) => ({
    ...a,
    cover: a.coverFileId ? fileMap.get(a.coverFileId) ?? null : null,
  }));
}

export async function listArticles(opts: { publishedOnly: boolean }): Promise<ArticleWithCover[]> {
  await ensureBootstrap();
  const rows = await db
    .select()
    .from(articles)
    .where(opts.publishedOnly ? eq(articles.isPublished, true) : undefined)
    .orderBy(desc(articles.createdAt), desc(articles.id));
  return attachCovers(rows);
}

export async function getArticle(
  id: number,
  opts: { publishedOnly: boolean },
): Promise<ArticleWithCover | null> {
  await ensureBootstrap();
  const [row] = await db
    .select()
    .from(articles)
    .where(and(eq(articles.id, id), opts.publishedOnly ? eq(articles.isPublished, true) : undefined));
  if (!row) return null;
  const [withCover] = await attachCovers([row]);
  return withCover ?? null;
}

export async function getFileById(id: number): Promise<FileRow | null> {
  const [row] = await db.select().from(mediaFiles).where(eq(mediaFiles.id, id));
  return row ?? null;
}

export async function getSettings(): Promise<Record<string, string>> {
  await ensureBootstrap();
  const rows = await db.select().from(siteSettings);
  const map: Record<string, string> = {};
  for (const row of rows) {
    if (row.key !== "admin_password_hash") map[row.key] = row.value;
  }
  return { ...DEFAULT_SETTINGS, ...map };
}

export async function getPasswordHash(): Promise<string | null> {
  await ensureBootstrap();
  const [row] = await db
    .select()
    .from(siteSettings)
    .where(eq(siteSettings.key, "admin_password_hash"));
  return row?.value ?? null;
}

export async function saveSettings(values: Record<string, string>): Promise<void> {
  for (const [key, value] of Object.entries(values)) {
    await db
      .insert(siteSettings)
      .values({ key, value })
      .onConflictDoUpdate({ target: siteSettings.key, set: { value } });
  }
}

// Удаляет файл с диска и из базы, если на него больше никто не ссылается.
export async function cleanupFiles(ids: number[]): Promise<void> {
  const unique = [...new Set(ids)];
  for (const id of unique) {
    const [blockRef] = await db
      .select({ id: lessonBlocks.id })
      .from(lessonBlocks)
      .where(eq(lessonBlocks.fileId, id))
      .limit(1);
    const [articleRef] = await db
      .select({ id: articles.id })
      .from(articles)
      .where(eq(articles.coverFileId, id))
      .limit(1);
    const [settingRef] = await db
      .select({ key: siteSettings.key })
      .from(siteSettings)
      .where(
        and(eq(siteSettings.key, "about_photo_file_id"), eq(siteSettings.value, String(id))),
      )
      .limit(1);
    if (blockRef || articleRef || settingRef) continue;
    const [file] = await db.select().from(mediaFiles).where(eq(mediaFiles.id, id));
    if (!file) continue;
    await db.delete(mediaFiles).where(eq(mediaFiles.id, id));
    await removeStoredFile(file.storagePath);
  }
}

export async function createLesson(title: string): Promise<LessonRow> {
  await ensureBootstrap();
  const all = await db.select({ position: lessons.position }).from(lessons);
  const position = all.reduce((max, r) => Math.max(max, r.position), 0) + 1;
  const [row] = await db.insert(lessons).values({ title, position }).returning();
  return row;
}

export async function updateLesson(
  id: number,
  patch: Partial<{ title: string; summary: string; isPublished: boolean }>,
): Promise<boolean> {
  const updated = await db
    .update(lessons)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(lessons.id, id))
    .returning({ id: lessons.id });
  return updated.length > 0;
}

export async function deleteLesson(id: number): Promise<void> {
  const blocks = await db
    .select({ fileId: lessonBlocks.fileId })
    .from(lessonBlocks)
    .where(eq(lessonBlocks.lessonId, id));
  await db.delete(lessons).where(eq(lessons.id, id));
  const fileIds = blocks.map((b) => b.fileId).filter((x): x is number => x !== null);
  if (fileIds.length) await cleanupFiles(fileIds);
}

export async function reorderLessons(ids: number[]): Promise<void> {
  for (let i = 0; i < ids.length; i++) {
    await db.update(lessons).set({ position: i + 1 }).where(eq(lessons.id, ids[i]));
  }
}

export type BlockInput = {
  kind: string;
  title: string;
  body: string;
  fileId: number | null;
  externalUrl: string;
};

export async function getBlock(id: number): Promise<BlockRow | null> {
  const [row] = await db.select().from(lessonBlocks).where(eq(lessonBlocks.id, id));
  return row ?? null;
}

export async function createBlock(lessonId: number, input: BlockInput): Promise<BlockRow> {
  const existing = await db
    .select({ position: lessonBlocks.position })
    .from(lessonBlocks)
    .where(eq(lessonBlocks.lessonId, lessonId));
  const position = existing.reduce((max, r) => Math.max(max, r.position), 0) + 1;
  const [row] = await db
    .insert(lessonBlocks)
    .values({ lessonId, position, ...input })
    .returning();
  return row;
}

export async function updateBlock(id: number, patch: Partial<BlockInput>): Promise<boolean> {
  const old = await getBlock(id);
  if (!old) return false;
  await db.update(lessonBlocks).set(patch).where(eq(lessonBlocks.id, id));
  if (patch.fileId !== undefined && old.fileId && old.fileId !== patch.fileId) {
    await cleanupFiles([old.fileId]);
  }
  return true;
}

export async function deleteBlock(id: number): Promise<boolean> {
  const old = await getBlock(id);
  if (!old) return false;
  await db.delete(lessonBlocks).where(eq(lessonBlocks.id, id));
  if (old.fileId) await cleanupFiles([old.fileId]);
  return true;
}

export async function reorderBlocks(lessonId: number, ids: number[]): Promise<void> {
  for (let i = 0; i < ids.length; i++) {
    await db
      .update(lessonBlocks)
      .set({ position: i + 1 })
      .where(and(eq(lessonBlocks.id, ids[i]), eq(lessonBlocks.lessonId, lessonId)));
  }
}

export async function createArticle(title: string): Promise<ArticleRow> {
  await ensureBootstrap();
  const [row] = await db.insert(articles).values({ title }).returning();
  return row;
}

export async function updateArticle(
  id: number,
  patch: Partial<{
    title: string;
    excerpt: string;
    body: string;
    coverFileId: number | null;
    isPublished: boolean;
  }>,
): Promise<boolean> {
  const [old] = await db.select().from(articles).where(eq(articles.id, id));
  if (!old) return false;
  await db
    .update(articles)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(articles.id, id));
  if (patch.coverFileId !== undefined && old.coverFileId && old.coverFileId !== patch.coverFileId) {
    await cleanupFiles([old.coverFileId]);
  }
  return true;
}

export async function deleteArticle(id: number): Promise<boolean> {
  const [old] = await db.select().from(articles).where(eq(articles.id, id));
  if (!old) return false;
  await db.delete(articles).where(eq(articles.id, id));
  if (old.coverFileId) await cleanupFiles([old.coverFileId]);
  return true;
}
