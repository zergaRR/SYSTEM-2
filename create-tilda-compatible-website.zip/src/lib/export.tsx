import { ZipArchive } from "archiver";
import { existsSync } from "node:fs";
import path from "node:path";
import { Readable } from "node:stream";
import type { ReactNode } from "react";
import { createRequire } from "node:module";

// react-dom/server подключаем во время выполнения, чтобы сборка не тянула его в серверные компоненты.
const nodeRequire = createRequire(path.join(process.cwd(), "package.json"));
function renderToStaticMarkup(element: ReactNode): string {
  const dom = nodeRequire("react-dom/server") as { renderToStaticMarkup: (el: ReactNode) => string };
  return dom.renderToStaticMarkup(element);
}
import {
  AboutView,
  ArticlesView,
  ArticleView,
  buildMediaItems,
  type Ctx,
  type FileRef,
  HomeView,
  LessonsView,
  LessonView,
  MediaView,
  type Route,
  routeKey,
  SiteFrame,
  StaticDocument,
} from "@/components/academy";
import {
  type ArticleWithCover,
  type LessonWithBlocks,
  getFileById,
  getSettings,
  listArticles,
  listLessons,
} from "@/lib/content";
import { SITE_JS } from "@/lib/site-script";
import { SITE_CSS } from "@/lib/theme";
import { storedFilePath } from "@/lib/storage";

export type PublicData = {
  settings: Record<string, string>;
  lessons: LessonWithBlocks[];
  articles: ArticleWithCover[];
  aboutPhoto: FileRef | null;
};

export async function loadPublicData(): Promise<PublicData> {
  const settings = await getSettings();
  const lessons = await listLessons({ publishedOnly: true });
  const articles = await listArticles({ publishedOnly: true });
  const photoId = Number(settings.about_photo_file_id);
  const aboutPhoto = photoId ? await getFileById(photoId) : null;
  return { settings, lessons, articles, aboutPhoto };
}

function extOf(storedName: string): string {
  return path.extname(storedName).replace(".", "") || "bin";
}

function staticHref(route: Route): string {
  switch (route.name) {
    case "home":
      return "index.html";
    case "lessons":
      return "lessons.html";
    case "lesson":
      return `lesson-${route.id}.html`;
    case "articles":
      return "articles.html";
    case "article":
      return `article-${route.id}.html`;
    case "media":
      return "media.html";
    case "about":
      return "about.html";
  }
}

function staticFile(file: FileRef): string {
  return `media/file-${file.id}.${extOf(file.storagePath)}`;
}

// Все файлы, которые используются опубликованным контентом.
export function collectMediaFiles(data: PublicData): FileRef[] {
  const map = new Map<number, FileRef>();
  for (const lesson of data.lessons) {
    for (const block of lesson.blocks) {
      if (block.file) map.set(block.file.id, block.file);
    }
  }
  for (const article of data.articles) {
    if (article.cover) map.set(article.cover.id, article.cover);
  }
  if (data.aboutPhoto) map.set(data.aboutPhoto.id, data.aboutPhoto);
  return [...map.values()];
}

// Страницы статического сайта для GitHub Pages.
export function buildStaticPages(data: PublicData): { path: string; html: string }[] {
  const ctx: Ctx = { mode: "static", href: staticHref, file: staticFile };
  const { settings, lessons, articles, aboutPhoto } = data;
  const mediaItems = buildMediaItems(lessons, ctx);

  const page = (file: string, title: string, active: string, content: ReactNode) => ({
    path: file,
    html:
      "<!DOCTYPE html>" +
      renderToStaticMarkup(
        <StaticDocument title={`${title} — ${settings.site_title}`}>
          <SiteFrame ctx={ctx} settings={settings} active={active}>
            {content}
          </SiteFrame>
        </StaticDocument>,
      ),
  });

  const pages: { path: string; html: string }[] = [];
  pages.push(
    page(
      "index.html",
      "Главная",
      "",
      <HomeView
        ctx={ctx}
        settings={settings}
        lessons={lessons}
        articles={articles}
        mediaCount={mediaItems.length}
      />,
    ),
  );
  pages.push(page("lessons.html", "Уроки", "lessons", <LessonsView ctx={ctx} lessons={lessons} />));
  lessons.forEach((lesson, i) => {
    pages.push(
      page(
        `lesson-${lesson.id}.html`,
        lesson.title,
        "lessons",
        <LessonView
          ctx={ctx}
          lesson={lesson}
          index={i}
          prev={i > 0 ? lessons[i - 1] : null}
          next={i < lessons.length - 1 ? lessons[i + 1] : null}
        />,
      ),
    );
  });
  pages.push(page("articles.html", "Статьи", "articles", <ArticlesView ctx={ctx} articles={articles} />));
  articles.forEach((article) => {
    pages.push(
      page(
        `article-${article.id}.html`,
        article.title,
        "articles",
        <ArticleView ctx={ctx} article={article} />,
      ),
    );
  });
  pages.push(page("media.html", "Медиатека", "media", <MediaView items={mediaItems} />));
  pages.push(
    page(
      "about.html",
      settings.about_title,
      "about",
      <AboutView ctx={ctx} settings={settings} photo={aboutPhoto} />,
    ),
  );
  return pages;
}

const GITHUB_README = [
  "ИНСТРУКЦИЯ: как выложить сайт на GitHub Pages (бесплатно)",
  "",
  "1. Зайдите на github.com и войдите в аккаунт (или зарегистрируйтесь).",
  "2. Нажмите «+» в правом верхнем углу → «New repository».",
  "   Название, например: academy. Выберите «Public». Нажмите «Create repository».",
  "3. На странице репозитория нажмите «uploading an existing file»",
  "   (или «Add file» → «Upload files»).",
  "4. Распакуйте этот ZIP-архив на компьютере. Откройте папку и выделите ВСЕ файлы",
  "   и папки внутри неё (сама папка не нужна). Перетащите их в окно GitHub.",
  "5. Внизу страницы нажмите «Commit changes».",
  "6. Откройте «Settings» → «Pages». В разделе «Build and deployment» → «Source»",
  "   выберите «Deploy from a branch». Branch: main, папка: / (root). Нажмите «Save».",
  "7. Через 1–2 минуты сайт откроется по адресу:",
  "   https://ВАШ-ЛОГИН.github.io/НАЗВАНИЕ-РЕПОЗИТОРИЯ/",
  "",
  "Важно:",
  "- Это статичная копия сайта. Чтобы обновить материалы, внесите изменения в админке,",
  "  заново скачайте ZIP и загрузите файлы в репозиторий (файлы с теми же именами заменятся).",
  "- Через браузер нельзя загрузить файлы больше 25 МБ, а GitHub не принимает файлы больше 100 МБ.",
  "  Большие видео загрузите на YouTube, RuTube или VK и вставьте ссылку в админке.",
  "- Редактировать материалы на GitHub нельзя: редактирование работает в админке на вашем сайте.",
  "",
].join("\n");

// ZIP-архив со статичным сайтом (потоковая упаковка, файлы не держатся в памяти целиком).
export function buildGithubZip(data: PublicData): ReadableStream {
  const archive = new ZipArchive({ zlib: { level: 6 } });
  archive.on("warning", () => undefined);
  archive.on("error", () => undefined);

  for (const p of buildStaticPages(data)) {
    archive.append(p.html, { name: p.path });
  }
  for (const file of collectMediaFiles(data)) {
    const source = storedFilePath(file.storagePath);
    if (existsSync(source)) {
      archive.file(source, { name: `media/file-${file.id}.${extOf(file.storagePath)}` });
    }
  }
  archive.append(GITHUB_README, { name: "README.txt" });
  archive.append("", { name: ".nojekyll" });
  void archive.finalize();
  return Readable.toWeb(archive) as unknown as ReadableStream;
}

// Один HTML-блок (CSS + разметка + JavaScript) для вставки в блок T123 «HTML-код» Тильды.
export function buildTildaCode(data: PublicData, origin: string): string {
  const base = (data.settings.public_base_url || origin).replace(/\/+$/, "");
  const ctx: Ctx = {
    mode: "spa",
    href: (route) => `#${routeKey(route)}`,
    file: (file) => `${base}/api/files/${file.id}`,
  };
  const { settings, lessons, articles, aboutPhoto } = data;
  const mediaItems = buildMediaItems(lessons, ctx);

  const block = (
    <>
      <style dangerouslySetInnerHTML={{ __html: SITE_CSS }} />
      <div className="acad-root acad-spa">
        <SiteFrame ctx={ctx} settings={settings} active="">
          <HomeView
            ctx={ctx}
            settings={settings}
            lessons={lessons}
            articles={articles}
            mediaCount={mediaItems.length}
          />
          <LessonsView ctx={ctx} lessons={lessons} />
          {lessons.map((lesson, i) => (
            <LessonView
              key={lesson.id}
              ctx={ctx}
              lesson={lesson}
              index={i}
              prev={i > 0 ? lessons[i - 1] : null}
              next={i < lessons.length - 1 ? lessons[i + 1] : null}
            />
          ))}
          <ArticlesView ctx={ctx} articles={articles} />
          {articles.map((article) => (
            <ArticleView key={article.id} ctx={ctx} article={article} />
          ))}
          <MediaView items={mediaItems} />
          <AboutView ctx={ctx} settings={settings} photo={aboutPhoto} />
        </SiteFrame>
      </div>
      <script dangerouslySetInnerHTML={{ __html: SITE_JS }} />
    </>
  );
  return renderToStaticMarkup(block);
}
