// Клиентский скрипт сайта (без React): прогресс в браузере, фильтры медиатеки,
// просмотрщик видео/фото/аудио, копирование кода и переключение разделов в режиме Тильды.
export const SITE_JS = `
(function () {
  var KEY = "academy-completed";

  function getDone() {
    try {
      var raw = localStorage.getItem(KEY);
      var arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr.map(String) : [];
    } catch (e) { return []; }
  }
  function setDone(arr) {
    try { localStorage.setItem(KEY, JSON.stringify(arr)); } catch (e) {}
  }
  function setText(sel, text) {
    document.querySelectorAll(sel).forEach(function (el) { el.textContent = text; });
  }
  function flash(btn, msg) {
    var old = btn.getAttribute("data-label") || btn.textContent;
    btn.setAttribute("data-label", old);
    btn.textContent = msg;
    setTimeout(function () { btn.textContent = old; }, 1800);
  }

  function renderProgress() {
    var done = getDone();
    var cards = document.querySelectorAll("[data-lesson-card]");
    var total = 0, count = 0, next = null, seen = {};
    cards.forEach(function (card) {
      var id = card.getAttribute("data-lesson-card");
      var isDone = done.indexOf(id) !== -1;
      if (!seen[id]) {
        seen[id] = true;
        total++;
        if (isDone) { count++; } else if (!next) { next = card.getAttribute("href"); }
      }
      card.classList.toggle("is-done", isDone);
      var tag = card.querySelector("[data-status]");
      if (tag) {
        tag.textContent = isDone ? "Пройден" : "Не пройден";
        tag.classList.toggle("tag-done", isDone);
      }
    });
    var pct = total ? Math.round((count / total) * 100) : 0;
    setText("[data-progress-done]", String(count));
    setText("[data-progress-total]", String(total));
    setText("[data-progress-pct]", pct + "%");
    document.querySelectorAll("[data-progress-bar]").forEach(function (el) { el.style.width = pct + "%"; });
    document.querySelectorAll("[data-next-lesson]").forEach(function (el) {
      if (next) {
        el.setAttribute("href", next);
        el.textContent = "Продолжить обучение";
      } else {
        el.textContent = total ? "Все уроки пройдены" : "Уроки скоро появятся";
      }
    });
    document.querySelectorAll("[data-complete-btn]").forEach(function (btn) {
      var isDone = done.indexOf(btn.getAttribute("data-complete-btn")) !== -1;
      btn.textContent = isDone ? "✓ Пройден (отменить)" : "Отметить как пройденный";
      btn.classList.toggle("btn-lime", isDone);
    });
  }

  var viewer = null;
  function closeViewer() { if (viewer && viewer.open) { viewer.close(); } }
  function ensureViewer() {
    if (viewer) { return viewer; }
    viewer = document.createElement("dialog");
    viewer.className = "viewer";
    viewer.innerHTML = '<div class="viewer-head"><h3 data-viewer-title></h3><button class="btn btn-sm" type="button" data-viewer-close>Закрыть</button></div><div data-viewer-body></div>';
    viewer.querySelector("[data-viewer-close]").addEventListener("click", closeViewer);
    viewer.addEventListener("click", function (ev) { if (ev.target === viewer) { closeViewer(); } });
    viewer.addEventListener("close", function () { viewer.querySelector("[data-viewer-body]").innerHTML = ""; });
    var root = document.querySelector(".acad-root") || document.body;
    root.appendChild(viewer);
    return viewer;
  }
  function openViewer(btn) {
    var dlg = ensureViewer();
    var kind = btn.getAttribute("data-kind") || "video";
    var src = btn.getAttribute("data-src") || "";
    var embed = btn.getAttribute("data-embed") || "";
    var title = btn.getAttribute("data-title") || "";
    var href = btn.getAttribute("data-href") || "";
    dlg.querySelector("[data-viewer-title]").textContent = title;
    var body = dlg.querySelector("[data-viewer-body]");
    body.innerHTML = "";
    var node;
    if (kind === "image") {
      node = document.createElement("img");
      node.src = src; node.alt = title; node.className = "media-img";
    } else if (kind === "audio") {
      node = document.createElement("audio");
      node.controls = true; node.src = src; node.style.width = "100%";
    } else if (embed) {
      node = document.createElement("iframe");
      node.src = embed;
      node.setAttribute("allowfullscreen", "");
      node.setAttribute("allow", "autoplay; fullscreen; picture-in-picture");
      node.style.cssText = "width:100%;aspect-ratio:16/9;border:0";
    } else {
      node = document.createElement("video");
      node.controls = true; node.playsInline = true; node.src = src;
      node.style.cssText = "width:100%;aspect-ratio:16/9;background:#000";
    }
    body.appendChild(node);
    if (href) {
      var a = document.createElement("a");
      a.href = href; a.className = "btn btn-sm"; a.style.marginTop = "14px";
      a.textContent = "Открыть урок";
      a.addEventListener("click", closeViewer);
      body.appendChild(a);
    }
    if (dlg.open) { dlg.close(); }
    dlg.showModal();
  }

  function routeSpa() {
    if (!document.querySelector(".acad-spa")) { return; }
    var h = window.location.hash.replace(/^#/, "") || "/";
    var found = false;
    document.querySelectorAll("[data-view]").forEach(function (v) {
      var on = v.getAttribute("data-view") === h;
      if (on) { found = true; }
      v.classList.toggle("is-active", on);
    });
    if (!found) {
      var home = document.querySelector('[data-view="/"]');
      if (home) { home.classList.add("is-active"); }
      h = "/";
    }
    var key = h.split("/")[1] || "home";
    document.querySelectorAll("[data-nav-key]").forEach(function (a) {
      a.classList.toggle("active", a.getAttribute("data-nav-key") === key);
    });
    if (window.__acadReady) {
      var root = document.querySelector(".acad-root");
      if (root) { root.scrollIntoView({ block: "start" }); }
    }
  }

  document.addEventListener("click", function (e) {
    var el = e.target && e.target.closest ? e.target : null;
    if (!el) { return; }

    var completeBtn = el.closest("[data-complete-btn]");
    if (completeBtn) {
      var id = completeBtn.getAttribute("data-complete-btn");
      var done = getDone();
      var idx = done.indexOf(id);
      if (idx === -1) { done.push(id); } else { done.splice(idx, 1); }
      setDone(done);
      renderProgress();
      return;
    }

    var filterBtn = el.closest("[data-filter]");
    if (filterBtn) {
      var f = filterBtn.getAttribute("data-filter");
      document.querySelectorAll("[data-filter]").forEach(function (b) {
        b.classList.toggle("is-active", b === filterBtn);
      });
      document.querySelectorAll("[data-media-item]").forEach(function (item) {
        item.classList.toggle("hidden", !(f === "all" || item.getAttribute("data-kind") === f));
      });
      return;
    }

    var openBtn = el.closest("[data-media-open]");
    if (openBtn) {
      e.preventDefault();
      openViewer(openBtn);
      return;
    }

    var copyBtn = el.closest("[data-copy]");
    if (copyBtn) {
      var field = document.querySelector(copyBtn.getAttribute("data-copy"));
      if (field) {
        field.focus();
        field.select();
        var text = field.value;
        var ok = function () { flash(copyBtn, "Скопировано!"); };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).then(ok, function () {
            try { document.execCommand("copy"); } catch (err) {}
            ok();
          });
        } else {
          try { document.execCommand("copy"); } catch (err) {}
          ok();
        }
      }
    }
  });

  window.addEventListener("hashchange", routeSpa);
  window.addEventListener("storage", renderProgress);

  function init() {
    renderProgress();
    routeSpa();
    window.__acadReady = true;
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
`;
