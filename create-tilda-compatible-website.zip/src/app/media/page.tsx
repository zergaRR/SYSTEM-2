import { MediaView, SiteFrame, buildMediaItems, liveCtx } from "@/components/academy";
import { getSettings, listLessons } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function MediaPage() {
  const settings = await getSettings();
  const lessons = await listLessons({ publishedOnly: true });
  const items = buildMediaItems(lessons, liveCtx);
  return (
    <SiteFrame ctx={liveCtx} settings={settings} active="media">
      <MediaView items={items} />
    </SiteFrame>
  );
}
