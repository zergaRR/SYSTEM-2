import { ArticlesView, SiteFrame, liveCtx } from "@/components/academy";
import { getSettings, listArticles } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function ArticlesPage() {
  const settings = await getSettings();
  const articles = await listArticles({ publishedOnly: true });
  return (
    <SiteFrame ctx={liveCtx} settings={settings} active="articles">
      <ArticlesView ctx={liveCtx} articles={articles} />
    </SiteFrame>
  );
}
