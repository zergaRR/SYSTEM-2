import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ArticleView, SiteFrame, liveCtx } from "@/components/academy";
import { getArticle, getSettings } from "@/lib/content";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const article = await getArticle(Number(id), { publishedOnly: true });
  return { title: article ? article.title : "Статья" };
}

export default async function ArticlePage({ params }: Props) {
  const { id } = await params;
  const articleId = Number(id);
  if (!Number.isInteger(articleId)) notFound();
  const settings = await getSettings();
  const article = await getArticle(articleId, { publishedOnly: true });
  if (!article) notFound();

  return (
    <SiteFrame ctx={liveCtx} settings={settings} active="articles">
      <ArticleView ctx={liveCtx} article={article} />
    </SiteFrame>
  );
}
