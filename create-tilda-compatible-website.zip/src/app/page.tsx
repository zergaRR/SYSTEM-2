import { HomeView, SiteFrame, buildMediaItems, liveCtx } from "@/components/academy";
import { getSettings, listArticles, listLessons } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const settings = await getSettings();
  const lessons = await listLessons({ publishedOnly: true });
  const articles = await listArticles({ publishedOnly: true });
  const mediaCount = buildMediaItems(lessons, liveCtx).length;

  return (
    <SiteFrame ctx={liveCtx} settings={settings} active="">
      <HomeView
        ctx={liveCtx}
        settings={settings}
        lessons={lessons}
        articles={articles}
        mediaCount={mediaCount}
      />
    </SiteFrame>
  );
}
