import type { Metadata } from "next";
import type { ReactNode } from "react";
import { SITE_CSS } from "@/lib/theme";
import { SITE_JS } from "@/lib/site-script";

export const metadata: Metadata = {
  title: "Академия команды",
  description: "Пошаговое обучение команды: видео, аудио, схемы и статьи.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <head>
        <style dangerouslySetInnerHTML={{ __html: SITE_CSS }} />
      </head>
      <body>
        <div className="acad-root">{children}</div>
        <script dangerouslySetInnerHTML={{ __html: SITE_JS }} />
      </body>
    </html>
  );
}
