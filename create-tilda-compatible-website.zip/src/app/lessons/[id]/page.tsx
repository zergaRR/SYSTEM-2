import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { LessonView, SiteFrame, liveCtx } from "@/components/academy";
import { getSettings, listLessons } from "@/lib/content";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const lessons = await listLessons({ publishedOnly: true });
  const lesson = lessons.find((l) => l.id === Number(id));
  return { title: lesson ? lesson.title : "Урок" };
}

export default async function LessonPage({ params }: Props) {
  const { id } = await params;
  const lessonId = Number(id);
  if (!Number.isInteger(lessonId)) notFound();
  const settings = await getSettings();
  const lessons = await listLessons({ publishedOnly: true });
  const index = lessons.findIndex((l) => l.id === lessonId);
  if (index === -1) notFound();

  return (
    <SiteFrame ctx={liveCtx} settings={settings} active="lessons">
      <LessonView
        ctx={liveCtx}
        lesson={lessons[index]}
        index={index}
        prev={index > 0 ? lessons[index - 1] : null}
        next={index < lessons.length - 1 ? lessons[index + 1] : null}
      />
    </SiteFrame>
  );
}
