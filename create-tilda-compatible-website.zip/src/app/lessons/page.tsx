import { LessonsView, SiteFrame, liveCtx } from "@/components/academy";
import { getSettings, listLessons } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function LessonsPage() {
  const settings = await getSettings();
  const lessons = await listLessons({ publishedOnly: true });
  return (
    <SiteFrame ctx={liveCtx} settings={settings} active="lessons">
      <LessonsView ctx={liveCtx} lessons={lessons} />
    </SiteFrame>
  );
}
