import { notFound } from "next/navigation";
import { LessonEditor } from "@/components/admin/AdminClient";
import { getLesson } from "@/lib/content";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

export default async function AdminLessonPage({ params }: Props) {
  const { id } = await params;
  const lessonId = Number(id);
  if (!Number.isInteger(lessonId)) notFound();
  const lesson = await getLesson(lessonId, { publishedOnly: false });
  if (!lesson) notFound();
  return <LessonEditor lesson={lesson} />;
}
