import { LessonList } from "@/components/admin/AdminClient";
import { listLessons } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function AdminLessonsPage() {
  const lessons = await listLessons({ publishedOnly: false });
  return (
    <LessonList
      lessons={lessons.map((l) => ({
        id: l.id,
        title: l.title,
        summary: l.summary,
        isPublished: l.isPublished,
        blockCount: l.blocks.length,
      }))}
    />
  );
}
