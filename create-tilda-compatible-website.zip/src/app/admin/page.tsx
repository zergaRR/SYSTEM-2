import { TildaCodeBox } from "@/components/admin/AdminClient";
import { listArticles, listLessons } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function AdminHome() {
  const allLessons = await listLessons({ publishedOnly: false });
  const allArticles = await listArticles({ publishedOnly: false });
  const mediaCount = allLessons
    .flatMap((l) => l.blocks)
    .filter((b) => b.kind === "video" || b.kind === "audio" || b.kind === "image").length;
  const publishedLessons = allLessons.filter((l) => l.isPublished).length;

  return (
    <>
      <h1 className="admin-title">Панель управления</h1>
      <p className="admin-sub">Здесь видно, что уже есть на сайте, и можно выгрузить материалы на GitHub или в Тильду.</p>

      <div className="admin-grid two" style={{ marginBottom: 34 }}>
        <div className="card">
          <div className="label">Уроков всего</div>
          <p className="display" style={{ fontSize: 36, margin: "6px 0 10px" }}>
            {allLessons.length}
          </p>
          <a href="/admin/lessons">Открыть уроки →</a>
        </div>
        <div className="card">
          <div className="label">Опубликовано уроков</div>
          <p className="display" style={{ fontSize: 36, margin: "6px 0 10px" }}>
            {publishedLessons}
          </p>
          <a href="/admin/lessons">Управлять публикацией →</a>
        </div>
        <div className="card">
          <div className="label">Видео, аудио и фото</div>
          <p className="display" style={{ fontSize: 36, margin: "6px 0 10px" }}>
            {mediaCount}
          </p>
          <a href="/media">Посмотреть медиатеку →</a>
        </div>
        <div className="card">
          <div className="label">Статей</div>
          <p className="display" style={{ fontSize: 36, margin: "6px 0 10px" }}>
            {allArticles.length}
          </p>
          <a href="/admin/articles">Открыть статьи →</a>
        </div>
      </div>

      <h2 className="display" style={{ fontSize: 24, marginBottom: 14 }}>
        Выгрузка сайта
      </h2>
      <div className="admin-grid two" style={{ marginBottom: 34 }}>
        <div className="card">
          <h3 style={{ fontSize: 20, marginBottom: 10 }}>1. GitHub (GitHub Pages)</h3>
          <p className="muted" style={{ marginBottom: 18 }}>
            Скачайте ZIP-архив со статичной копией сайта. Внутри есть файл README.txt с пошаговой инструкцией.
          </p>
          <a className="btn btn-lime" href="/api/admin/export/github">
            Скачать ZIP для GitHub
          </a>
        </div>
        <div className="card">
          <h3 style={{ fontSize: 20, marginBottom: 10 }}>2. Тильда</h3>
          <p className="muted" style={{ marginBottom: 16 }}>
            Весь сайт — это один HTML-код. Скопируйте его и вставьте в блок «T123. HTML-код» на странице Тильды.
          </p>
          <div className="row" style={{ marginBottom: 12 }}>
            <button type="button" className="btn btn-primary" data-copy="#tilda-code">
              Скопировать код
            </button>
            <a className="btn" href="/api/admin/export/tilda">
              Скачать файл .html
            </a>
          </div>
          <TildaCodeBox />
        </div>
      </div>

      <h2 id="instructions" className="display" style={{ fontSize: 24, marginBottom: 14 }}>
        Инструкция
      </h2>
      <div className="steps" style={{ marginBottom: 60 }}>
        <div>
          <h3>Как добавить урок</h3>
          <p>
            Откройте «Уроки» → «Создать урок». Введите название и нажмите «Сохранить урок». Внутри урока
            добавляйте материалы кнопкой «Добавить материал».
          </p>
        </div>
        <div>
          <h3>Как добавить видео</h3>
          <p>
            Выберите тип «Видео». Либо загрузите файл (MP4 или WEBM до 200 МБ), либо нажмите «Вставить ссылку» и
            вставьте ссылку на YouTube, RuTube или VK. Большие видео удобнее загрузить на YouTube или RuTube и
            вставить ссылку.
          </p>
        </div>
        <div>
          <h3>Фото, схемы и аудио</h3>
          <p>
            Выберите «Фото или схема» или «Аудио» и загрузите файл. Все фото, схемы, аудио и видео автоматически
            появляются в медиатеке.
          </p>
        </div>
        <div>
          <h3>Текст и статьи</h3>
          <p>
            Текст урока пишется в блоке «Текст». Отдельные статьи создаются в разделе «Статьи», там же можно
            загрузить обложку. Заголовок — строка, начинающаяся с ##. Список — строки, начинающиеся с «- ».
            Жирный текст — **слово**.
          </p>
        </div>
        <div>
          <h3>Порядок и публикация</h3>
          <p>
            Стрелками ↑ ↓ меняйте порядок уроков и материалов. Урок с галочкой «Опубликован» виден ученикам,
            черновик скрыт. Кнопки «Изменить» и «Удалить» есть у каждого материала.
          </p>
        </div>
        <div>
          <h3>Пароль</h3>
          <p>
            Пароль по умолчанию — admin12345. Смените его в разделе «Настройки и пароль» сразу после первого входа.
          </p>
        </div>
        <div>
          <h3>Выгрузка на Тильду</h3>
          <p>
            1) Нажмите «Скопировать код» выше. 2) В Тильде создайте страницу, нажмите «+», откройте раздел «Другое» и
            добавьте блок «T123. HTML-код». 3) Откройте блок, вставьте код в поле «HTML-код внутри блока» и нажмите
            «Применить». 4) Опубликуйте страницу. Разделы сайта переключаются внутри одной страницы. Сайт с
            материалами должен быть открыт в интернете, поэтому сначала опубликуйте его (адрес укажите в
            «Настройках»).
          </p>
        </div>
        <div>
          <h3>Выгрузка на GitHub</h3>
          <p>
            1) Скачайте ZIP и распакуйте его. 2) На github.com создайте репозиторий и нажмите «uploading an existing
            file». 3) Перетащите в окно все файлы из распакованной папки и нажмите «Commit changes». 4) В «Settings» →
            «Pages» выберите публикацию из ветки main. Подробности — в README.txt внутри архива.
          </p>
        </div>
      </div>
    </>
  );
}
