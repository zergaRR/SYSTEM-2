import { SettingsForm } from "@/components/admin/AdminClient";
import { getFileById, getSettings } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function AdminSettingsPage() {
  const settings = await getSettings();
  const photoId = Number(settings.about_photo_file_id);
  const photo = photoId ? await getFileById(photoId) : null;
  return (
    <SettingsForm
      settings={settings}
      photo={photo ? { id: photo.id, name: photo.originalName } : null}
    />
  );
}
