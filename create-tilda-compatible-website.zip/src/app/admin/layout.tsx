import type { ReactNode } from "react";
import { AdminShell, LoginForm } from "@/components/admin/AdminClient";
import { isAdminPage } from "@/lib/auth";

export const dynamic = "force-dynamic";

// Все страницы /admin доступны только после входа по паролю.
export default async function AdminLayout({ children }: { children: ReactNode }) {
  if (!(await isAdminPage())) {
    return (
      <div className="admin-wrap">
        <LoginForm />
      </div>
    );
  }
  return <AdminShell>{children}</AdminShell>;
}
