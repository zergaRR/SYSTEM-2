import { notFound } from "next/navigation";
import { ArticleEditor } from "@/components/admin/AdminClient";
import { getArticle } from "@/lib/content";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

export default async function AdminArticlePage({ params }: Props) {
  const { id } = await params;
  const articleId = Number(id);
  if (!Number.isInteger(articleId)) notFound();
  const article = await getArticle(articleId, { publishedOnly: false });
  if (!article) notFound();
  return <ArticleEditor article={article} />;
}
