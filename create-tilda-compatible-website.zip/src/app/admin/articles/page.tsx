import { ArticleList } from "@/components/admin/AdminClient";
import { listArticles } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function AdminArticlesPage() {
  const articles = await listArticles({ publishedOnly: false });
  return (
    <ArticleList
      articles={articles.map((a) => ({
        id: a.id,
        title: a.title,
        excerpt: a.excerpt,
        isPublished: a.isPublished,
      }))}
    />
  );
}
