import { AboutView, SiteFrame, liveCtx } from "@/components/academy";
import { getFileById, getSettings } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function AboutPage() {
  const settings = await getSettings();
  const photoId = Number(settings.about_photo_file_id);
  const photo = photoId ? await getFileById(photoId) : null;
  return (
    <SiteFrame ctx={liveCtx} settings={settings} active="about">
      <AboutView ctx={liveCtx} settings={settings} photo={photo} />
    </SiteFrame>
  );
}
