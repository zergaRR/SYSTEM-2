import { requireAdmin } from "@/lib/auth";
import { type MediaKind, saveUpload } from "@/lib/storage";

export const dynamic = "force-dynamic";

const KINDS: MediaKind[] = ["image", "video", "audio"];

// Загрузка фото, видео или аудио. Возвращает id файла для привязки к блоку или статье.
export async function POST(request: Request): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;

  const form = await request.formData();
  const file = form.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return Response.json({ error: "Выберите файл." }, { status: 400 });
  }
  const allowedRaw = String(form.get("allowed") ?? "image,video,audio");
  const allowed = allowedRaw
    .split(",")
    .map((s) => s.trim())
    .filter((s): s is MediaKind => (KINDS as string[]).includes(s));

  try {
    const row = await saveUpload(file, allowed.length > 0 ? allowed : KINDS);
    return Response.json({
      id: row.id,
      name: row.originalName,
      mimeType: row.mimeType,
      url: `/api/files/${row.id}`,
    });
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : "Не удалось загрузить файл." },
      { status: 400 },
    );
  }
}
