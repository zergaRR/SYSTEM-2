import { cookies } from "next/headers";
import {
  ADMIN_COOKIE,
  checkPassword,
  createSession,
  destroySession,
  isSecureRequest,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

// Вход в админку по паролю.
export async function POST(request: Request): Promise<Response> {
  const body = (await request.json().catch(() => null)) as { password?: unknown } | null;
  const password = typeof body?.password === "string" ? body.password : "";
  if (!password) {
    return Response.json({ error: "Введите пароль." }, { status: 400 });
  }
  if (!(await checkPassword(password))) {
    await new Promise((resolve) => setTimeout(resolve, 700));
    return Response.json({ error: "Неверный пароль." }, { status: 401 });
  }
  const { token, expires } = await createSession();
  const secure = isSecureRequest(request) ? "; Secure" : "";
  return Response.json(
    { ok: true },
    {
      headers: {
        "Set-Cookie": `${ADMIN_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Expires=${expires.toUTCString()}${secure}`,
      },
    },
  );
}

// Выход из админки.
export async function DELETE(): Promise<Response> {
  const store = await cookies();
  await destroySession(store.get(ADMIN_COOKIE)?.value);
  return Response.json(
    { ok: true },
    { headers: { "Set-Cookie": `${ADMIN_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax` } },
  );
}
