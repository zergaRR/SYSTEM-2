import { deleteLesson, updateLesson } from "@/lib/content";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

// Изменение урока: название, краткое описание, публикация.
export async function PATCH(request: Request, { params }: Props): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const lessonId = Number((await params).id);
  if (!Number.isInteger(lessonId)) {
    return Response.json({ error: "Урок не найден." }, { status: 404 });
  }
  const body = ((await request.json().catch(() => ({}))) ?? {}) as Record<string, unknown>;
  const patch: Partial<{ title: string; summary: string; isPublished: boolean }> = {};
  if (typeof body.title === "string") {
    const title = body.title.trim().slice(0, 200);
    if (!title) return Response.json({ error: "Название не может быть пустым." }, { status: 400 });
    patch.title = title;
  }
  if (typeof body.summary === "string") patch.summary = body.summary.trim().slice(0, 1000);
  if (typeof body.isPublished === "boolean") patch.isPublished = body.isPublished;
  if (Object.keys(patch).length === 0) {
    return Response.json({ error: "Нет данных для сохранения." }, { status: 400 });
  }
  const ok = await updateLesson(lessonId, patch);
  return ok
    ? Response.json({ ok: true })
    : Response.json({ error: "Урок не найден." }, { status: 404 });
}

// Удаление урока вместе с его блоками.
export async function DELETE(_request: Request, { params }: Props): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const lessonId = Number((await params).id);
  if (!Number.isInteger(lessonId)) {
    return Response.json({ error: "Урок не найден." }, { status: 404 });
  }
  await deleteLesson(lessonId);
  return Response.json({ ok: true });
}
