import { createLesson } from "@/lib/content";
import { requireAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

// Создание нового урока (шага).
export async function POST(request: Request): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const body = (await request.json().catch(() => null)) as { title?: unknown } | null;
  const title = typeof body?.title === "string" ? body.title.trim().slice(0, 200) : "";
  if (!title) {
    return Response.json({ error: "Введите название урока." }, { status: 400 });
  }
  const lesson = await createLesson(title);
  return Response.json({ id: lesson.id });
}
