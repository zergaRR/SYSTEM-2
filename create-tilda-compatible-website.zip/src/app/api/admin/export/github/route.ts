import { requireAdmin } from "@/lib/auth";
import { buildGithubZip, loadPublicData } from "@/lib/export";

export const dynamic = "force-dynamic";

// Скачивание статичного сайта (ZIP) для загрузки на GitHub Pages.
export async function GET(): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const data = await loadPublicData();
  const stream = buildGithubZip(data);
  const date = new Date().toISOString().slice(0, 10);
  return new Response(stream, {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename="academy-github-${date}.zip"`,
    },
  });
}
