import { requireAdmin } from "@/lib/auth";
import { buildTildaCode, loadPublicData } from "@/lib/export";

export const dynamic = "force-dynamic";

function originOf(request: Request): string {
  const url = new URL(request.url);
  const proto = request.headers.get("x-forwarded-proto") ?? url.protocol.replace(":", "");
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? url.host;
  return `${proto}://${host}`;
}

// Скачивание HTML-кода для блока T123 «HTML-код» в Тильде.
export async function GET(request: Request): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const data = await loadPublicData();
  const code = buildTildaCode(data, originOf(request));
  return new Response(code, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Content-Disposition": 'attachment; filename="tilda-academy-code.html"',
    },
  });
}
