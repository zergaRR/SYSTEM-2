import { deleteBlock, updateBlock } from "@/lib/content";
import { requireAdmin } from "@/lib/auth";
import { parseBlockBody } from "@/lib/validation";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

// Изменение блока.
export async function PATCH(request: Request, { params }: Props): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const blockId = Number((await params).id);
  if (!Number.isInteger(blockId)) {
    return Response.json({ error: "Блок не найден." }, { status: 404 });
  }
  const body = (await request.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return Response.json({ error: "Нет данных." }, { status: 400 });
  const parsed = parseBlockBody(body, "update");
  if (!parsed.ok) return Response.json({ error: parsed.error }, { status: 400 });
  const ok = await updateBlock(blockId, parsed.value);
  return ok
    ? Response.json({ ok: true })
    : Response.json({ error: "Блок не найден." }, { status: 404 });
}

// Удаление блока.
export async function DELETE(_request: Request, { params }: Props): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const blockId = Number((await params).id);
  if (!Number.isInteger(blockId)) {
    return Response.json({ error: "Блок не найден." }, { status: 404 });
  }
  const ok = await deleteBlock(blockId);
  return ok
    ? Response.json({ ok: true })
    : Response.json({ error: "Блок не найден." }, { status: 404 });
}
