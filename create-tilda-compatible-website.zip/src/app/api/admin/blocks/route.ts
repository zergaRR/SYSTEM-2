import { createBlock } from "@/lib/content";
import { requireAdmin } from "@/lib/auth";
import { parseBlockBody } from "@/lib/validation";

export const dynamic = "force-dynamic";

// Добавление блока (видео, аудио, фото или текст) в урок.
export async function POST(request: Request): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const body = (await request.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return Response.json({ error: "Нет данных." }, { status: 400 });
  const lessonId = typeof body.lessonId === "number" ? body.lessonId : NaN;
  if (!Number.isInteger(lessonId)) {
    return Response.json({ error: "Урок не найден." }, { status: 400 });
  }
  const parsed = parseBlockBody(body, "create");
  if (!parsed.ok) return Response.json({ error: parsed.error }, { status: 400 });
  const block = await createBlock(lessonId, {
    kind: parsed.value.kind ?? "text",
    title: parsed.value.title ?? "",
    body: parsed.value.body ?? "",
    fileId: parsed.value.fileId ?? null,
    externalUrl: parsed.value.externalUrl ?? "",
  });
  return Response.json({ id: block.id });
}
