import { checkPassword, requireAdmin } from "@/lib/auth";
import { cleanupFiles, getSettings, saveSettings } from "@/lib/content";
import { hashPassword } from "@/lib/password";

export const dynamic = "force-dynamic";

const SHORT_KEYS = ["site_title", "site_subtitle", "about_title", "public_base_url", "about_photo_file_id"];

// Сохранение настроек сайта и смена пароля администратора.
export async function PUT(request: Request): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;

  const body = ((await request.json().catch(() => ({}))) ?? {}) as {
    values?: Record<string, unknown>;
    currentPassword?: unknown;
    newPassword?: unknown;
  };
  const source: Record<string, unknown> = body.values ?? {};
  const before = await getSettings();
  const values: Record<string, string> = {};

  for (const key of SHORT_KEYS) {
    if (key in source) {
      const raw = source[key];
      values[key] = typeof raw === "string" ? raw.trim().slice(0, 500) : "";
    }
  }
  if ("about_text" in source) {
    const raw = source.about_text;
    values.about_text = typeof raw === "string" ? raw.slice(0, 20000) : "";
  }
  if ("site_title" in values && !values.site_title) {
    return Response.json({ error: "Название сайта не может быть пустым." }, { status: 400 });
  }
  if (values.public_base_url && !/^https?:\/\/\S+$/i.test(values.public_base_url)) {
    return Response.json(
      { error: "Адрес сайта должен начинаться с https:// (например, https://academy.example.ru)." },
      { status: 400 },
    );
  }
  if (values.about_photo_file_id && !/^\d+$/.test(values.about_photo_file_id)) {
    values.about_photo_file_id = "";
  }

  if (typeof body.newPassword === "string") {
    if (body.newPassword.length < 6) {
      return Response.json({ error: "Новый пароль должен быть не короче 6 символов." }, { status: 400 });
    }
    const current = typeof body.currentPassword === "string" ? body.currentPassword : "";
    if (!(await checkPassword(current))) {
      return Response.json({ error: "Текущий пароль указан неверно." }, { status: 400 });
    }
    values.admin_password_hash = hashPassword(body.newPassword);
  }

  if (Object.keys(values).length > 0) await saveSettings(values);

  if (
    values.about_photo_file_id !== undefined &&
    before.about_photo_file_id &&
    before.about_photo_file_id !== values.about_photo_file_id
  ) {
    const oldId = Number(before.about_photo_file_id);
    if (Number.isInteger(oldId) && oldId > 0) await cleanupFiles([oldId]);
  }
  return Response.json({ ok: true });
}
