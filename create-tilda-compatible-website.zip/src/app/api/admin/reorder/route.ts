import { requireAdmin } from "@/lib/auth";
import { reorderBlocks, reorderLessons } from "@/lib/content";

export const dynamic = "force-dynamic";

// Новый порядок уроков или блоков внутри урока: { type: "lessons" | "blocks", lessonId?, ids: [...] }.
export async function POST(request: Request): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const body = (await request.json().catch(() => null)) as Record<string, unknown> | null;
  const rawIds: unknown[] = Array.isArray(body?.ids) ? (body?.ids as unknown[]) : [];
  const ids = rawIds.filter((x): x is number => typeof x === "number" && Number.isInteger(x));

  if (body?.type === "lessons") {
    await reorderLessons(ids);
    return Response.json({ ok: true });
  }
  if (body?.type === "blocks" && typeof body.lessonId === "number" && Number.isInteger(body.lessonId)) {
    await reorderBlocks(body.lessonId, ids);
    return Response.json({ ok: true });
  }
  return Response.json({ error: "Неверный запрос." }, { status: 400 });
}
