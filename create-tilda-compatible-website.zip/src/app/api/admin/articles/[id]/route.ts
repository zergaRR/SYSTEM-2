import { requireAdmin } from "@/lib/auth";
import { deleteArticle, updateArticle } from "@/lib/content";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

// Изменение статьи: заголовок, описание, текст, обложка, публикация.
export async function PATCH(request: Request, { params }: Props): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const articleId = Number((await params).id);
  if (!Number.isInteger(articleId)) {
    return Response.json({ error: "Статья не найдена." }, { status: 404 });
  }
  const body = ((await request.json().catch(() => ({}))) ?? {}) as Record<string, unknown>;
  const patch: Partial<{
    title: string;
    excerpt: string;
    body: string;
    coverFileId: number | null;
    isPublished: boolean;
  }> = {};
  if (typeof body.title === "string") {
    const title = body.title.trim().slice(0, 200);
    if (!title) return Response.json({ error: "Название не может быть пустым." }, { status: 400 });
    patch.title = title;
  }
  if (typeof body.excerpt === "string") patch.excerpt = body.excerpt.trim().slice(0, 500);
  if (typeof body.body === "string") patch.body = body.body.slice(0, 50000);
  if ("coverFileId" in body) {
    patch.coverFileId =
      typeof body.coverFileId === "number" && Number.isInteger(body.coverFileId)
        ? body.coverFileId
        : null;
  }
  if (typeof body.isPublished === "boolean") patch.isPublished = body.isPublished;
  if (Object.keys(patch).length === 0) {
    return Response.json({ error: "Нет данных для сохранения." }, { status: 400 });
  }
  const ok = await updateArticle(articleId, patch);
  return ok
    ? Response.json({ ok: true })
    : Response.json({ error: "Статья не найдена." }, { status: 404 });
}

// Удаление статьи.
export async function DELETE(_request: Request, { params }: Props): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const articleId = Number((await params).id);
  if (!Number.isInteger(articleId)) {
    return Response.json({ error: "Статья не найдена." }, { status: 404 });
  }
  const ok = await deleteArticle(articleId);
  return ok
    ? Response.json({ ok: true })
    : Response.json({ error: "Статья не найдена." }, { status: 404 });
}
