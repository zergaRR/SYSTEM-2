import { requireAdmin } from "@/lib/auth";
import { createArticle } from "@/lib/content";

export const dynamic = "force-dynamic";

// Создание новой статьи.
export async function POST(request: Request): Promise<Response> {
  const denied = await requireAdmin();
  if (denied) return denied;
  const body = (await request.json().catch(() => null)) as { title?: unknown } | null;
  const title = typeof body?.title === "string" ? body.title.trim().slice(0, 200) : "";
  if (!title) {
    return Response.json({ error: "Введите название статьи." }, { status: 400 });
  }
  const article = await createArticle(title);
  return Response.json({ id: article.id });
}
