import { createReadStream, promises as fs } from "node:fs";
import { Readable } from "node:stream";
import { getFileById } from "@/lib/content";
import { storedFilePath } from "@/lib/storage";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

function notFound(): Response {
  return new Response("Файл не найден", { status: 404 });
}

// Отдаёт загруженные фото, видео и аудио. Поддерживает перемотку (Range), чтобы видео запускалось и перематывалось.
export async function GET(request: Request, { params }: Props): Promise<Response> {
  const { id } = await params;
  const fileId = Number(id);
  if (!Number.isInteger(fileId)) return notFound();

  const file = await getFileById(fileId);
  if (!file) return notFound();

  const fullPath = storedFilePath(file.storagePath);
  let total: number;
  try {
    total = (await fs.stat(fullPath)).size;
  } catch {
    return notFound();
  }

  const headers: Record<string, string> = {
    "Content-Type": file.mimeType,
    "Accept-Ranges": "bytes",
    "Cache-Control": "public, max-age=86400",
    "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(file.originalName)}`,
  };

  const range = request.headers.get("range");
  const match = range ? /bytes=(\d*)-(\d*)/.exec(range) : null;
  if (match && (match[1] || match[2])) {
    let start: number;
    let end: number;
    if (!match[1]) {
      const suffix = parseInt(match[2], 10);
      start = Math.max(total - suffix, 0);
      end = total - 1;
    } else {
      start = parseInt(match[1], 10);
      end = match[2] ? parseInt(match[2], 10) : total - 1;
    }
    end = Math.min(end, total - 1);
    if (start > end || start >= total) {
      return new Response(null, {
        status: 416,
        headers: { "Content-Range": `bytes */${total}` },
      });
    }
    const stream = Readable.toWeb(createReadStream(fullPath, { start, end })) as unknown as ReadableStream;
    return new Response(stream, {
      status: 206,
      headers: {
        ...headers,
        "Content-Range": `bytes ${start}-${end}/${total}`,
        "Content-Length": String(end - start + 1),
      },
    });
  }

  const stream = Readable.toWeb(createReadStream(fullPath)) as unknown as ReadableStream;
  return new Response(stream, {
    status: 200,
    headers: { ...headers, "Content-Length": String(total) },
  });
}
