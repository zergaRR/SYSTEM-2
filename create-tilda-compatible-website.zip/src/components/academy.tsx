import type { ReactNode } from "react";
import type { ArticleWithCover, BlockWithFile, LessonWithBlocks } from "@/lib/content";
import { renderMarkdown, safeHttpUrl, toEmbedUrl } from "@/lib/format";
import { SITE_CSS } from "@/lib/theme";
import { SITE_JS } from "@/lib/site-script";

// Общие типы для живого сайта, выгрузки на GitHub и кода для Тильды.
export type Route =
  | { name: "home" }
  | { name: "lessons" }
  | { name: "lesson"; id: number }
  | { name: "articles" }
  | { name: "article"; id: number }
  | { name: "media" }
  | { name: "about" };

export type FileRef = { id: number; mimeType: string; storagePath: string; originalName: string };
export type Settings = Record<string, string>;
export type Ctx = {
  mode: "live" | "static" | "spa";
  href: (route: Route) => string;
  file: (file: FileRef) => string;
};

export type MediaItem = {
  key: string;
  kind: "video" | "audio" | "image";
  title: string;
  src: string | null;
  embed: string | null;
  step: number;
  lessonTitle: string;
  lessonHref: string;
};

export function routeKey(route: Route): string {
  switch (route.name) {
    case "home":
      return "/";
    case "lessons":
      return "/lessons";
    case "lesson":
      return `/lessons/${route.id}`;
    case "articles":
      return "/articles";
    case "article":
      return `/articles/${route.id}`;
    case "media":
      return "/media";
    case "about":
      return "/about";
  }
}

// Контекст для живого сайта: обычные адреса страниц и загрузка файлов через API.
export const liveCtx: Ctx = {
  mode: "live",
  href: (route) => routeKey(route),
  file: (file) => `/api/files/${file.id}`,
};

const KIND_LABEL: Record<string, string> = { video: "Видео", audio: "Аудио", image: "Фото" };

function blockSrc(block: BlockWithFile, ctx: Ctx): string | null {
  if (block.file) return ctx.file(block.file);
  return safeHttpUrl(block.externalUrl);
}

function blockEmbed(block: BlockWithFile): string | null {
  if (block.file || block.kind !== "video") return null;
  return toEmbedUrl(block.externalUrl);
}

export function buildMediaItems(lessons: LessonWithBlocks[], ctx: Ctx): MediaItem[] {
  const items: MediaItem[] = [];
  lessons.forEach((lesson, index) => {
    for (const block of lesson.blocks) {
      if (block.kind !== "video" && block.kind !== "audio" && block.kind !== "image") continue;
      items.push({
        key: `b${block.id}`,
        kind: block.kind,
        title: block.title || block.file?.originalName || "Материал",
        src: blockSrc(block, ctx),
        embed: blockEmbed(block),
        step: index + 1,
        lessonTitle: lesson.title,
        lessonHref: ctx.href({ name: "lesson", id: lesson.id }),
      });
    }
  });
  return items;
}

function MediaBlock({ block, ctx }: { block: BlockWithFile; ctx: Ctx }) {
  const src = blockSrc(block, ctx);
  const embed = blockEmbed(block);
  const title = block.title || block.file?.originalName || "Материал";
  let content: ReactNode;
  if (block.kind === "image") {
    content = src ? (
      <img className="media-img" src={src} alt={title} loading="lazy" />
    ) : (
      <p className="muted">Фото не найдено.</p>
    );
  } else if (block.kind === "audio") {
    content = src ? <audio controls preload="none" src={src} /> : <p className="muted">Аудио не найдено.</p>;
  } else if (embed) {
    content = (
      <div className="media-frame">
        <iframe
          src={embed}
          title={title}
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
          loading="lazy"
        />
      </div>
    );
  } else if (src) {
    content = (
      <div className="media-frame">
        <video controls playsInline preload="metadata" src={src} />
      </div>
    );
  } else {
    content = <p className="muted">Видео не найдено.</p>;
  }
  return (
    <>
      {content}
      {block.body ? <p className="caption">{block.body}</p> : null}
    </>
  );
}

function BlockView({ block, ctx }: { block: BlockWithFile; ctx: Ctx }) {
  const title = block.title ? <h2>{block.title}</h2> : null;
  if (block.kind === "text") {
    return (
      <article className="block">
        {title}
        <div className="text" dangerouslySetInnerHTML={{ __html: renderMarkdown(block.body) }} />
      </article>
    );
  }
  return (
    <article className="block">
      {title}
      <MediaBlock block={block} ctx={ctx} />
    </article>
  );
}

export function SiteFrame({
  ctx,
  settings,
  active,
  children,
}: {
  ctx: Ctx;
  settings: Settings;
  active: string;
  children: ReactNode;
}) {
  const nav: { key: string; label: string; route: Route }[] = [
    { key: "lessons", label: "Уроки", route: { name: "lessons" } },
    { key: "articles", label: "Статьи", route: { name: "articles" } },
    { key: "media", label: "Медиатека", route: { name: "media" } },
    { key: "about", label: "О наставнике", route: { name: "about" } },
  ];
  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <a className="logo" href={ctx.href({ name: "home" })} data-nav-key="home">
            {settings.site_title}
          </a>
          <nav className="nav">
            {nav.map((n) => (
              <a
                key={n.key}
                href={ctx.href(n.route)}
                data-nav-key={n.key}
                className={active === n.key ? "active" : undefined}
              >
                {n.label}
              </a>
            ))}
          </nav>
        </div>
      </header>
      <main>{children}</main>
      <footer className="foot">
        <div className="wrap">{settings.site_title} · Учебные материалы команды</div>
      </footer>
    </>
  );
}

export function HomeView({
  ctx,
  settings,
  lessons,
  articles,
  mediaCount,
}: {
  ctx: Ctx;
  settings: Settings;
  lessons: LessonWithBlocks[];
  articles: ArticleWithCover[];
  mediaCount: number;
}) {
  const first = lessons[0];
  return (
    <div data-view="/">
      <section className="wrap hero">
        <span className="badge">Обучение команды</span>
        <h1 className="display">{settings.site_title}</h1>
        <p className="sub">{settings.site_subtitle}</p>
        <div className="card progress-card">
          <div style={{ flex: 1, minWidth: 220 }}>
            <div className="label">Ваш прогресс</div>
            <div className="row" style={{ marginTop: 6 }}>
              <strong className="display" style={{ fontSize: 22 }}>
                <span data-progress-done>0</span>/<span data-progress-total>{lessons.length}</span>
              </strong>
              <span className="muted" data-progress-pct>
                0%
              </span>
            </div>
            <div className="bar" style={{ marginTop: 10 }}>
              <span data-progress-bar />
            </div>
          </div>
          {first ? (
            <a className="btn btn-primary" href={ctx.href({ name: "lesson", id: first.id })} data-next-lesson>
              Начать обучение
            </a>
          ) : (
            <span className="btn">Уроки скоро появятся</span>
          )}
        </div>
        <div className="hidden">
          {lessons.map((l) => (
            <a key={l.id} href={ctx.href({ name: "lesson", id: l.id })} data-lesson-card={l.id}>
              {l.title}
            </a>
          ))}
        </div>
      </section>
      <section className="wrap">
        <div className="tiles">
          <a className="card-link" href={ctx.href({ name: "lessons" })}>
            <div className="tile-title">Уроки</div>
            <p className="muted">{lessons.length} шагов обучения</p>
          </a>
          <a className="card-link" href={ctx.href({ name: "articles" })}>
            <div className="tile-title">Статьи</div>
            <p className="muted">{articles.length} материалов для чтения</p>
          </a>
          <a className="card-link" href={ctx.href({ name: "media" })}>
            <div className="tile-title">Медиатека</div>
            <p className="muted">{mediaCount} видео, аудио и фото из уроков</p>
          </a>
          <a className="card-link" href={ctx.href({ name: "about" })}>
            <div className="tile-title">{settings.about_title}</div>
            <p className="muted">Кто поможет на пути в команде</p>
          </a>
        </div>
      </section>
      {articles.length > 0 ? (
        <section className="wrap" style={{ paddingBottom: 60 }}>
          <h2 className="display" style={{ fontSize: 24, marginBottom: 18 }}>
            Новые статьи
          </h2>
          <div className="article-list" style={{ marginBottom: 0 }}>
            {articles.slice(0, 3).map((a) => (
              <ArticleCard key={a.id} article={a} ctx={ctx} />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

export function LessonsView({ ctx, lessons }: { ctx: Ctx; lessons: LessonWithBlocks[] }) {
  return (
    <div data-view="/lessons" className="wrap">
      <div className="page-head">
        <h1 className="display">Уроки</h1>
        <p>
          Проходите шаги по порядку. Отмечайте пройденные уроки: прогресс сохраняется в вашем браузере.
        </p>
      </div>
      {lessons.length === 0 ? <p className="muted">Уроки скоро появятся.</p> : null}
      <div className="lesson-list">
        {lessons.map((l, i) => (
          <a
            key={l.id}
            className="lesson-card"
            href={ctx.href({ name: "lesson", id: l.id })}
            data-lesson-card={l.id}
          >
            <div className="step-no">{i + 1}</div>
            <div>
              <h3>{l.title}</h3>
              {l.summary ? <p>{l.summary}</p> : null}
              <div className="meta">
                <span className="tag" data-status>
                  Не пройден
                </span>
                <span className="muted" style={{ fontSize: 14 }}>
                  Материалов: {l.blocks.length}
                </span>
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}

export function LessonView({
  ctx,
  lesson,
  index,
  prev,
  next,
}: {
  ctx: Ctx;
  lesson: LessonWithBlocks;
  index: number;
  prev: LessonWithBlocks | null;
  next: LessonWithBlocks | null;
}) {
  return (
    <div data-view={routeKey({ name: "lesson", id: lesson.id })} className="wrap-narrow">
      <div className="lesson-head">
        <a className="muted" href={ctx.href({ name: "lessons" })}>
          ← Все уроки
        </a>
        <div style={{ marginTop: 14 }}>
          <span className="tag tag-blue">Шаг {index + 1}</span>
        </div>
        <h1 className="display">{lesson.title}</h1>
        {lesson.summary ? <p>{lesson.summary}</p> : null}
      </div>
      <div className="blocks">
        {lesson.blocks.map((b) => (
          <BlockView key={b.id} block={b} ctx={ctx} />
        ))}
      </div>
      {lesson.blocks.length === 0 ? <p className="muted">Материалы появятся позже.</p> : null}
      <div className="row" style={{ marginBottom: 28 }}>
        <button className="btn btn-primary" type="button" data-complete-btn={lesson.id}>
          Отметить как пройденный
        </button>
      </div>
      <nav className="pager">
        {prev ? (
          <a className="btn" href={ctx.href({ name: "lesson", id: prev.id })}>
            ← {prev.title}
          </a>
        ) : (
          <span />
        )}
        {next ? (
          <a className="btn btn-lime" href={ctx.href({ name: "lesson", id: next.id })}>
            {next.title} →
          </a>
        ) : (
          <span />
        )}
      </nav>
    </div>
  );
}

function ArticleCard({ article, ctx }: { article: ArticleWithCover; ctx: Ctx }) {
  return (
    <a className="article-card" href={ctx.href({ name: "article", id: article.id })}>
      {article.cover ? (
        <img className="thumb" src={ctx.file(article.cover)} alt={article.title} loading="lazy" />
      ) : (
        <div className="thumb-empty" />
      )}
      <div className="info">
        <h3>{article.title}</h3>
        {article.excerpt ? <p>{article.excerpt}</p> : null}
      </div>
    </a>
  );
}

export function ArticlesView({ ctx, articles }: { ctx: Ctx; articles: ArticleWithCover[] }) {
  return (
    <div data-view="/articles" className="wrap">
      <div className="page-head">
        <h1 className="display">Статьи</h1>
        <p>Материалы для чтения: памятки, разборы и инструкции для команды.</p>
      </div>
      {articles.length === 0 ? <p className="muted">Статей пока нет.</p> : null}
      <div className="article-list">
        {articles.map((a) => (
          <ArticleCard key={a.id} article={a} ctx={ctx} />
        ))}
      </div>
    </div>
  );
}

export function ArticleView({ ctx, article }: { ctx: Ctx; article: ArticleWithCover }) {
  return (
    <div data-view={routeKey({ name: "article", id: article.id })} className="wrap-narrow" style={{ paddingBottom: 60 }}>
      <div style={{ paddingTop: 36 }}>
        <a className="muted" href={ctx.href({ name: "articles" })}>
          ← Все статьи
        </a>
      </div>
      <h1 className="display" style={{ fontSize: "clamp(26px, 4.5vw, 40px)", marginTop: 14 }}>
        {article.title}
      </h1>
      {article.excerpt ? (
        <p className="muted" style={{ marginTop: 12, fontSize: 18 }}>
          {article.excerpt}
        </p>
      ) : null}
      {article.cover ? <img className="article-cover" src={ctx.file(article.cover)} alt={article.title} /> : null}
      <div className="article-body" dangerouslySetInnerHTML={{ __html: renderMarkdown(article.body) }} />
    </div>
  );
}

const FILTERS: { id: string; label: string }[] = [
  { id: "all", label: "Все" },
  { id: "video", label: "Видео" },
  { id: "audio", label: "Аудио" },
  { id: "image", label: "Фото и схемы" },
];

export function MediaView({ items }: { items: MediaItem[] }) {
  return (
    <div data-view="/media" className="wrap">
      <div className="page-head">
        <h1 className="display">Медиатека</h1>
        <p>Все видео, аудио и фото из уроков — удобно пересмотреть перед встречей.</p>
      </div>
      <div className="filters">
        {FILTERS.map((f, i) => {
          const count = f.id === "all" ? items.length : items.filter((x) => x.kind === f.id).length;
          return (
            <button
              key={f.id}
              type="button"
              className={i === 0 ? "filter-btn is-active" : "filter-btn"}
              data-filter={f.id}
            >
              {f.label} ({count})
            </button>
          );
        })}
      </div>
      {items.length === 0 ? (
        <p className="muted">Материалов пока нет. Добавьте видео, аудио или фото в уроках.</p>
      ) : null}
      <div className="media-grid">
        {items.map((item) => (
          <div key={item.key} className="media-card" data-media-item data-kind={item.kind}>
            <button
              type="button"
              className="media-thumb"
              data-media-open
              data-kind={item.kind}
              data-src={item.src ?? ""}
              data-embed={item.embed ?? ""}
              data-title={item.title}
              data-href={item.lessonHref}
            >
              {item.kind === "image" && item.src ? (
                <img src={item.src} alt={item.title} loading="lazy" />
              ) : (
                <span className="play">{item.kind === "audio" ? "♪" : "▶"}</span>
              )}
              <span className="kind">{KIND_LABEL[item.kind]}</span>
            </button>
            <div className="media-info">
              <h3>{item.title}</h3>
              <a href={item.lessonHref}>
                Шаг {item.step} · {item.lessonTitle}
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function AboutView({
  ctx,
  settings,
  photo,
}: {
  ctx: Ctx;
  settings: Settings;
  photo: FileRef | null;
}) {
  return (
    <div data-view="/about" className="wrap-narrow" style={{ paddingBottom: 60 }}>
      <div className="page-head">
        <h1 className="display">{settings.about_title}</h1>
      </div>
      {photo ? (
        <img
          src={ctx.file(photo)}
          alt={settings.about_title}
          className="media-img"
          style={{ marginBottom: 24, maxWidth: 380 }}
        />
      ) : null}
      <div className="article-body" dangerouslySetInnerHTML={{ __html: renderMarkdown(settings.about_text) }} />
    </div>
  );
}

// Полный HTML-документ для ZIP-выгрузки на GitHub Pages.
export function StaticDocument({ title, children }: { title: string; children: ReactNode }) {
  return (
    <html lang="ru">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>{title}</title>
        <style dangerouslySetInnerHTML={{ __html: SITE_CSS }} />
      </head>
      <body>
        <div className="acad-root">{children}</div>
        <script dangerouslySetInnerHTML={{ __html: SITE_JS }} />
      </body>
    </html>
  );
}
