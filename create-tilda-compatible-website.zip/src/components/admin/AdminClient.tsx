"use client";

import { useRouter } from "next/navigation";
import { type ChangeEvent, type FormEvent, type ReactNode, useEffect, useState } from "react";
import type { ArticleWithCover, BlockWithFile, LessonWithBlocks } from "@/lib/content";

type ApiResult = { ok: true; data: Record<string, unknown> } | { ok: false; error: string };
type Message = { kind: "ok" | "error"; text: string };
type MediaKind = "image" | "video" | "audio";
type MediaValue = { fileId: number | null; externalUrl: string };

async function callApi(url: string, method: string, body?: unknown): Promise<ApiResult> {
  try {
    const res = await fetch(url, {
      method,
      headers: body === undefined ? undefined : { "Content-Type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const data = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    if (!res.ok) {
      return { ok: false, error: typeof data.error === "string" ? data.error : `Ошибка ${res.status}` };
    }
    return { ok: true, data };
  } catch {
    return { ok: false, error: "Нет связи с сервером. Попробуйте ещё раз." };
  }
}

function Notice({ kind, children }: { kind: "ok" | "error"; children: ReactNode }) {
  return (
    <div className={kind === "error" ? "notice error" : "notice"} role="status">
      {children}
    </div>
  );
}

const KIND_OPTIONS: { value: string; label: string; hint: string }[] = [
  {
    value: "video",
    label: "Видео",
    hint: "Загрузите видеофайл (MP4, WEBM, MOV до 200 МБ) или вставьте ссылку на YouTube, RuTube или VK.",
  },
  {
    value: "audio",
    label: "Аудио",
    hint: "Загрузите MP3, M4A, WAV или OGG до 80 МБ либо вставьте прямую ссылку на аудиофайл.",
  },
  { value: "image", label: "Фото или схема", hint: "JPG, PNG, WEBP или GIF до 15 МБ." },
  {
    value: "text",
    label: "Текст",
    hint: "Напишите текст урока. Поддерживается простая разметка, подсказка ниже.",
  },
];

function kindLabel(kind: string): string {
  return KIND_OPTIONS.find((o) => o.value === kind)?.label ?? kind;
}

// Выбор файла (загрузка на сервер) или вставка ссылки.
function MediaPicker({
  label,
  hint,
  allowed,
  value,
  fileName,
  onChange,
  allowLink = true,
}: {
  label: string;
  hint?: string;
  allowed: MediaKind[];
  value: MediaValue;
  fileName: string | null;
  onChange: (value: MediaValue, name?: string) => void;
  allowLink?: boolean;
}) {
  const [mode, setMode] = useState<"file" | "link">(value.externalUrl ? "link" : "file");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const accept = allowed.map((k) => `${k}/*`).join(",");

  async function handleFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    setError(null);
    const form = new FormData();
    form.append("file", file);
    form.append("allowed", allowed.join(","));
    try {
      const res = await fetch("/api/admin/files", { method: "POST", body: form });
      const data = (await res.json().catch(() => ({}))) as { id?: number; name?: string; error?: string };
      if (!res.ok || !data.id) {
        setError(data.error ?? "Не удалось загрузить файл.");
      } else {
        onChange({ fileId: data.id, externalUrl: "" }, data.name ?? file.name);
      }
    } catch {
      setError("Нет связи с сервером. Попробуйте ещё раз.");
    } finally {
      setBusy(false);
      e.target.value = "";
    }
  }

  return (
    <div className="field">
      <span className="label">{label}</span>
      {hint ? <span className="hint">{hint}</span> : null}
      {allowLink ? (
        <div className="row">
          <button
            type="button"
            className={mode === "file" ? "btn btn-sm btn-lime" : "btn btn-sm"}
            onClick={() => setMode("file")}
          >
            Загрузить файл
          </button>
          <button
            type="button"
            className={mode === "link" ? "btn btn-sm btn-lime" : "btn btn-sm"}
            onClick={() => setMode("link")}
          >
            Вставить ссылку
          </button>
        </div>
      ) : null}
      {mode === "file" ? (
        <>
          <input type="file" accept={accept} onChange={handleFile} disabled={busy} />
          {busy ? <span className="hint">Загружаем файл, подождите…</span> : null}
          {value.fileId && fileName ? <span className="hint">Выбран файл: {fileName}</span> : null}
        </>
      ) : (
        <input
          type="url"
          placeholder="https://..."
          value={value.externalUrl}
          onChange={(e) => onChange({ fileId: null, externalUrl: e.target.value })}
        />
      )}
      {error ? <Notice kind="error">{error}</Notice> : null}
    </div>
  );
}

export function LoginForm() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const r = await callApi("/api/admin/session", "POST", { password });
    setBusy(false);
    if (!r.ok) {
      setError(r.error);
      return;
    }
    router.refresh();
  }

  return (
    <div className="login-box card">
      <h1 className="admin-title">Вход в админку</h1>
      <p className="admin-sub">Введите пароль администратора.</p>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <form onSubmit={submit}>
        <div className="field">
          <label htmlFor="admin-password">Пароль</label>
          <input
            id="admin-password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoFocus
          />
        </div>
        <button className="btn btn-primary" type="submit" disabled={busy || !password}>
          {busy ? "Входим…" : "Войти"}
        </button>
      </form>
      <p className="hint" style={{ marginTop: 18 }}>
        Первый вход: пароль по умолчанию <b>admin12345</b>. Сразу смените его в разделе «Настройки».
      </p>
    </div>
  );
}

// Поле с кодом для Тильды: код загружается из API, поэтому серверная страница не зависит от генератора HTML.
export function TildaCodeBox() {
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    fetch("/api/admin/export/tilda")
      .then(async (res) => {
        if (!res.ok) throw new Error("bad status");
        return res.text();
      })
      .then((text) => {
        if (alive) setCode(text);
      })
      .catch(() => {
        if (alive) setError("Не удалось подготовить код. Обновите страницу.");
      });
    return () => {
      alive = false;
    };
  }, []);

  return (
    <>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <textarea
        id="tilda-code"
        className="codebox"
        readOnly
        value={code}
        placeholder="Готовим код…"
      />
    </>
  );
}

export function AdminShell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const links: [string, string][] = [
    ["/admin", "Главная и выгрузка"],
    ["/admin/lessons", "Уроки"],
    ["/admin/articles", "Статьи"],
    ["/admin/settings", "Настройки и пароль"],
    ["/", "Открыть сайт"],
  ];

  async function logout() {
    await callApi("/api/admin/session", "DELETE");
    router.refresh();
  }

  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <a className="logo" href="/admin">
            Админка
          </a>
          <nav className="nav">
            {links.map(([href, label]) => (
              <a key={href} href={href}>
                {label}
              </a>
            ))}
          </nav>
          <button className="btn btn-sm" type="button" onClick={logout}>
            Выйти
          </button>
        </div>
      </header>
      <div className="admin-wrap">{children}</div>
    </>
  );
}

type LessonRowData = {
  id: number;
  title: string;
  summary: string;
  isPublished: boolean;
  blockCount: number;
};

export function LessonList({ lessons }: { lessons: LessonRowData[] }) {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function create(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setBusy(true);
    setError(null);
    const r = await callApi("/api/admin/lessons", "POST", { title });
    setBusy(false);
    if (!r.ok) {
      setError(r.error);
      return;
    }
    router.push(`/admin/lessons/${String(r.data.id)}`);
  }

  async function move(index: number, dir: -1 | 1) {
    const ids = lessons.map((l) => l.id);
    const j = index + dir;
    if (j < 0 || j >= ids.length) return;
    [ids[index], ids[j]] = [ids[j], ids[index]];
    const r = await callApi("/api/admin/reorder", "POST", { type: "lessons", ids });
    if (r.ok) router.refresh();
    else setError(r.error);
  }

  async function togglePublish(lesson: LessonRowData) {
    const r = await callApi(`/api/admin/lessons/${lesson.id}`, "PATCH", {
      isPublished: !lesson.isPublished,
    });
    if (r.ok) router.refresh();
    else setError(r.error);
  }

  async function remove(lesson: LessonRowData) {
    if (!window.confirm(`Удалить урок «${lesson.title}» и все его материалы?`)) return;
    const r = await callApi(`/api/admin/lessons/${lesson.id}`, "DELETE");
    if (r.ok) router.refresh();
    else setError(r.error);
  }

  return (
    <>
      <h1 className="admin-title">Уроки</h1>
      <p className="admin-sub">
        Каждый урок — это шаг обучения. Порядок меняется стрелками. Откройте урок, чтобы добавить видео, фото,
        аудио и текст.
      </p>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <form className="card" onSubmit={create} style={{ marginBottom: 28 }}>
        <div className="field" style={{ marginBottom: 12 }}>
          <label htmlFor="new-lesson">Новый урок</label>
          <input
            id="new-lesson"
            type="text"
            maxLength={200}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Например: Как провести первую встречу"
          />
        </div>
        <button className="btn btn-primary" type="submit" disabled={busy || !title.trim()}>
          Создать урок
        </button>
      </form>
      {lessons.length === 0 ? <p className="muted">Уроков пока нет.</p> : null}
      {lessons.length > 0 ? (
        <div style={{ overflowX: "auto" }}>
          <table className="table">
            <thead>
              <tr>
                <th>№</th>
                <th>Название</th>
                <th>Материалов</th>
                <th>Статус</th>
                <th>Порядок</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              {lessons.map((l, i) => (
                <tr key={l.id}>
                  <td>{i + 1}</td>
                  <td>
                    <a href={`/admin/lessons/${l.id}`}>
                      <b>{l.title}</b>
                    </a>
                  </td>
                  <td>{l.blockCount}</td>
                  <td>
                    <span className={l.isPublished ? "tag tag-done" : "tag tag-draft"}>
                      {l.isPublished ? "Опубликован" : "Черновик"}
                    </span>
                  </td>
                  <td>
                    <div className="row">
                      <button className="btn btn-sm" type="button" onClick={() => move(i, -1)} disabled={i === 0}>
                        ↑
                      </button>
                      <button
                        className="btn btn-sm"
                        type="button"
                        onClick={() => move(i, 1)}
                        disabled={i === lessons.length - 1}
                      >
                        ↓
                      </button>
                    </div>
                  </td>
                  <td>
                    <div className="row">
                      <a className="btn btn-sm btn-primary" href={`/admin/lessons/${l.id}`}>
                        Открыть
                      </a>
                      <button className="btn btn-sm" type="button" onClick={() => togglePublish(l)}>
                        {l.isPublished ? "Скрыть" : "Опубликовать"}
                      </button>
                      <button className="btn btn-sm btn-danger" type="button" onClick={() => remove(l)}>
                        Удалить
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </>
  );
}

const TEXT_HINT =
  "Заголовок — строка, начинающаяся с ##. Список — строки, начинающиеся с «- ». Жирный текст: **слово**. Цитата — строка, начинающаяся с &gt;. Ссылка: [текст](https://адрес). Пустая строка — новый абзац.";

// Форма добавления или изменения блока (видео, аудио, фото или текст).
function BlockEditor({
  lessonId,
  block,
  onDone,
}: {
  lessonId?: number;
  block?: BlockWithFile;
  onDone: () => void;
}) {
  const [kind, setKind] = useState<string>(block?.kind ?? "video");
  const [title, setTitle] = useState(block?.title ?? "");
  const [body, setBody] = useState(block?.body ?? "");
  const [media, setMedia] = useState<MediaValue>({
    fileId: block?.fileId ?? null,
    externalUrl: block?.externalUrl ?? "",
  });
  const [fileName, setFileName] = useState<string | null>(block?.file?.originalName ?? null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isText = kind === "text";
  const allowed: MediaKind[] = kind === "video" ? ["video"] : kind === "audio" ? ["audio"] : ["image"];
  const hint = KIND_OPTIONS.find((o) => o.value === kind)?.hint ?? "";

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const payload = {
      kind,
      title,
      body,
      fileId: isText ? null : media.fileId,
      externalUrl: isText ? "" : media.externalUrl,
    };
    const r = block
      ? await callApi(`/api/admin/blocks/${block.id}`, "PATCH", payload)
      : await callApi("/api/admin/blocks", "POST", { ...payload, lessonId });
    setBusy(false);
    if (!r.ok) {
      setError(r.error);
      return;
    }
    onDone();
  }

  return (
    <form className="card" onSubmit={submit}>
      <div className="admin-grid two">
        <div className="field">
          <label htmlFor={`kind-${block?.id ?? "new"}`}>Тип материала</label>
          <select id={`kind-${block?.id ?? "new"}`} value={kind} onChange={(e) => setKind(e.target.value)}>
            {KIND_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>Название</label>
          <input
            type="text"
            maxLength={200}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Например: Приветствие наставника"
          />
        </div>
      </div>
      <p className="hint" style={{ marginBottom: 14 }}>
        {hint}
      </p>
      {isText ? (
        <div className="field">
          <label>Текст</label>
          <textarea rows={9} value={body} onChange={(e) => setBody(e.target.value)} />
          <span className="hint">{TEXT_HINT}</span>
        </div>
      ) : (
        <>
          <MediaPicker
            label="Файл или ссылка"
            allowed={allowed}
            value={media}
            fileName={fileName}
            onChange={(v, name) => {
              setMedia(v);
              setFileName(name ?? null);
            }}
          />
          <div className="field">
            <label>Подпись (необязательно)</label>
            <textarea rows={2} value={body} onChange={(e) => setBody(e.target.value)} />
          </div>
        </>
      )}
      {error ? <Notice kind="error">{error}</Notice> : null}
      <div className="row">
        <button className="btn btn-primary" type="submit" disabled={busy}>
          {busy ? "Сохраняем…" : block ? "Сохранить материал" : "Добавить материал"}
        </button>
      </div>
    </form>
  );
}

function BlockItem({
  block,
  index,
  total,
  onMove,
  onChanged,
}: {
  block: BlockWithFile;
  index: number;
  total: number;
  onMove: (dir: -1 | 1) => void;
  onChanged: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function remove() {
    if (!window.confirm("Удалить этот материал?")) return;
    const r = await callApi(`/api/admin/blocks/${block.id}`, "DELETE");
    if (r.ok) onChanged();
    else setError(r.error);
  }

  const preview =
    block.kind === "text"
      ? block.body.slice(0, 160) + (block.body.length > 160 ? "…" : "")
      : block.file
        ? `Файл: ${block.file.originalName}`
        : block.externalUrl
          ? `Ссылка: ${block.externalUrl}`
          : "Файл не выбран";

  return (
    <div className="block-item">
      <div className="row" style={{ justifyContent: "space-between" }}>
        <div className="row">
          <span className="tag tag-blue">{kindLabel(block.kind)}</span>
          <b>{block.title || block.file?.originalName || "Без названия"}</b>
        </div>
        <div className="row">
          <button className="btn btn-sm" type="button" onClick={() => onMove(-1)} disabled={index === 0}>
            ↑
          </button>
          <button className="btn btn-sm" type="button" onClick={() => onMove(1)} disabled={index === total - 1}>
            ↓
          </button>
          <button className="btn btn-sm" type="button" onClick={() => setEditing(!editing)}>
            {editing ? "Свернуть" : "Изменить"}
          </button>
          <button className="btn btn-sm btn-danger" type="button" onClick={remove}>
            Удалить
          </button>
        </div>
      </div>
      {error ? <Notice kind="error">{error}</Notice> : null}
      {editing ? (
        <BlockEditor
          block={block}
          onDone={() => {
            setEditing(false);
            onChanged();
          }}
        />
      ) : (
        <p className="hint">{preview}</p>
      )}
    </div>
  );
}

export function LessonEditor({ lesson }: { lesson: LessonWithBlocks }) {
  const router = useRouter();
  const [title, setTitle] = useState(lesson.title);
  const [summary, setSummary] = useState(lesson.summary);
  const [isPublished, setPublished] = useState(lesson.isPublished);
  const [message, setMessage] = useState<Message | null>(null);
  const [busy, setBusy] = useState(false);
  const [formKey, setFormKey] = useState(0);
  const blocks = lesson.blocks;

  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMessage(null);
    const r = await callApi(`/api/admin/lessons/${lesson.id}`, "PATCH", { title, summary, isPublished });
    setBusy(false);
    if (r.ok) {
      setMessage({ kind: "ok", text: "Урок сохранён." });
      router.refresh();
    } else {
      setMessage({ kind: "error", text: r.error });
    }
  }

  async function remove() {
    if (!window.confirm("Удалить урок и все его материалы?")) return;
    const r = await callApi(`/api/admin/lessons/${lesson.id}`, "DELETE");
    if (r.ok) router.push("/admin/lessons");
    else setMessage({ kind: "error", text: r.error });
  }

  async function moveBlock(index: number, dir: -1 | 1) {
    const ids = blocks.map((b) => b.id);
    const j = index + dir;
    if (j < 0 || j >= ids.length) return;
    [ids[index], ids[j]] = [ids[j], ids[index]];
    const r = await callApi("/api/admin/reorder", "POST", { type: "blocks", lessonId: lesson.id, ids });
    if (r.ok) router.refresh();
    else setMessage({ kind: "error", text: r.error });
  }

  return (
    <>
      <p>
        <a className="muted" href="/admin/lessons">
          ← Все уроки
        </a>
      </p>
      <h1 className="admin-title" style={{ marginTop: 10 }}>
        Урок: {lesson.title}
      </h1>
      <p className="admin-sub">Сначала сохраните название и описание, затем добавляйте материалы ниже.</p>
      {message ? <Notice kind={message.kind}>{message.text}</Notice> : null}
      <form className="card" onSubmit={save} style={{ marginBottom: 32 }}>
        <div className="field">
          <label htmlFor="lesson-title">Название урока</label>
          <input
            id="lesson-title"
            type="text"
            maxLength={200}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <div className="field">
          <label htmlFor="lesson-summary">Короткое описание (показывается в списке уроков)</label>
          <input
            id="lesson-summary"
            type="text"
            maxLength={1000}
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
          />
        </div>
        <label className="check" style={{ marginBottom: 18 }}>
          <input type="checkbox" checked={isPublished} onChange={(e) => setPublished(e.target.checked)} />
          Опубликован (виден ученикам)
        </label>
        <div className="row">
          <button className="btn btn-primary" type="submit" disabled={busy}>
            {busy ? "Сохраняем…" : "Сохранить урок"}
          </button>
          <a className="btn" href={`/lessons/${lesson.id}`} target="_blank" rel="noreferrer">
            Посмотреть на сайте
          </a>
          <button className="btn btn-danger" type="button" onClick={remove}>
            Удалить урок
          </button>
        </div>
      </form>

      <h2 className="display" style={{ fontSize: 22, marginBottom: 14 }}>
        Материалы урока
      </h2>
      {blocks.length === 0 ? <p className="muted" style={{ marginBottom: 16 }}>Материалов пока нет.</p> : null}
      <div className="admin-grid" style={{ marginBottom: 32 }}>
        {blocks.map((b, i) => (
          <BlockItem
            key={b.id}
            block={b}
            index={i}
            total={blocks.length}
            onMove={(dir) => moveBlock(i, dir)}
            onChanged={() => router.refresh()}
          />
        ))}
      </div>

      <h2 className="display" style={{ fontSize: 22, marginBottom: 14 }}>
        Добавить материал
      </h2>
      <BlockEditor
        key={formKey}
        lessonId={lesson.id}
        onDone={() => {
          setFormKey((k) => k + 1);
          router.refresh();
        }}
      />
    </>
  );
}

type ArticleRowData = { id: number; title: string; excerpt: string; isPublished: boolean };

export function ArticleList({ articles }: { articles: ArticleRowData[] }) {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function create(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setBusy(true);
    setError(null);
    const r = await callApi("/api/admin/articles", "POST", { title });
    setBusy(false);
    if (!r.ok) {
      setError(r.error);
      return;
    }
    router.push(`/admin/articles/${String(r.data.id)}`);
  }

  async function remove(article: ArticleRowData) {
    if (!window.confirm(`Удалить статью «${article.title}»?`)) return;
    const r = await callApi(`/api/admin/articles/${article.id}`, "DELETE");
    if (r.ok) router.refresh();
    else setError(r.error);
  }

  return (
    <>
      <h1 className="admin-title">Статьи</h1>
      <p className="admin-sub">Статьи для чтения: памятки, разборы, инструкции. Каждая статья получает обложку и текст.</p>
      {error ? <Notice kind="error">{error}</Notice> : null}
      <form className="card" onSubmit={create} style={{ marginBottom: 28 }}>
        <div className="field" style={{ marginBottom: 12 }}>
          <label htmlFor="new-article">Новая статья</label>
          <input
            id="new-article"
            type="text"
            maxLength={200}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Например: Памятка для первой встречи"
          />
        </div>
        <button className="btn btn-primary" type="submit" disabled={busy || !title.trim()}>
          Создать статью
        </button>
      </form>
      {articles.length === 0 ? <p className="muted">Статей пока нет.</p> : null}
      <div className="admin-grid">
        {articles.map((a) => (
          <div key={a.id} className="block-item">
            <div className="row" style={{ justifyContent: "space-between" }}>
              <div className="row">
                <span className={a.isPublished ? "tag tag-done" : "tag tag-draft"}>
                  {a.isPublished ? "Опубликована" : "Черновик"}
                </span>
                <a href={`/admin/articles/${a.id}`}>
                  <b>{a.title}</b>
                </a>
              </div>
              <div className="row">
                <a className="btn btn-sm btn-primary" href={`/admin/articles/${a.id}`}>
                  Редактировать
                </a>
                <button className="btn btn-sm btn-danger" type="button" onClick={() => remove(a)}>
                  Удалить
                </button>
              </div>
            </div>
            {a.excerpt ? <p className="hint">{a.excerpt}</p> : null}
          </div>
        ))}
      </div>
    </>
  );
}

export function ArticleEditor({ article }: { article: ArticleWithCover }) {
  const router = useRouter();
  const [title, setTitle] = useState(article.title);
  const [excerpt, setExcerpt] = useState(article.excerpt);
  const [body, setBody] = useState(article.body);
  const [isPublished, setPublished] = useState(article.isPublished);
  const [cover, setCover] = useState<MediaValue>({ fileId: article.coverFileId, externalUrl: "" });
  const [coverName, setCoverName] = useState<string | null>(article.cover?.originalName ?? null);
  const [message, setMessage] = useState<Message | null>(null);
  const [busy, setBusy] = useState(false);

  async function save(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMessage(null);
    const r = await callApi(`/api/admin/articles/${article.id}`, "PATCH", {
      title,
      excerpt,
      body,
      isPublished,
      coverFileId: cover.fileId,
    });
    setBusy(false);
    if (r.ok) {
      setMessage({ kind: "ok", text: "Статья сохранена." });
      router.refresh();
    } else {
      setMessage({ kind: "error", text: r.error });
    }
  }

  async function remove() {
    if (!window.confirm("Удалить статью?")) return;
    const r = await callApi(`/api/admin/articles/${article.id}`, "DELETE");
    if (r.ok) router.push("/admin/articles");
    else setMessage({ kind: "error", text: r.error });
  }

  return (
    <>
      <p>
        <a className="muted" href="/admin/articles">
          ← Все статьи
        </a>
      </p>
      <h1 className="admin-title" style={{ marginTop: 10 }}>
        Статья
      </h1>
      {message ? <Notice kind={message.kind}>{message.text}</Notice> : null}
      <form className="card" onSubmit={save}>
        <div className="field">
          <label htmlFor="article-title">Заголовок</label>
          <input
            id="article-title"
            type="text"
            maxLength={200}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
        <div className="field">
          <label htmlFor="article-excerpt">Короткое описание (для карточки)</label>
          <textarea id="article-excerpt" rows={2} value={excerpt} onChange={(e) => setExcerpt(e.target.value)} />
        </div>
        <MediaPicker
          label="Обложка (необязательно)"
          hint="Картинка для карточки статьи и верха страницы."
          allowed={["image"]}
          allowLink={false}
          value={cover}
          fileName={coverName}
          onChange={(v, name) => {
            setCover(v);
            if (name) setCoverName(name);
          }}
        />
        {cover.fileId ? (
          <button
            className="btn btn-sm"
            type="button"
            style={{ marginBottom: 16 }}
            onClick={() => {
              setCover({ fileId: null, externalUrl: "" });
              setCoverName(null);
            }}
          >
            Убрать обложку
          </button>
        ) : null}
        <div className="field">
          <label htmlFor="article-body">Текст статьи</label>
          <textarea
            id="article-body"
            rows={18}
            value={body}
            onChange={(e) => setBody(e.target.value)}
          />
          <span className="hint">{TEXT_HINT}</span>
        </div>
        <label className="check" style={{ marginBottom: 18 }}>
          <input type="checkbox" checked={isPublished} onChange={(e) => setPublished(e.target.checked)} />
          Опубликована (видна на сайте)
        </label>
        <div className="row">
          <button className="btn btn-primary" type="submit" disabled={busy}>
            {busy ? "Сохраняем…" : "Сохранить статью"}
          </button>
          <a className="btn" href={`/articles/${article.id}`} target="_blank" rel="noreferrer">
            Посмотреть на сайте
          </a>
          <button className="btn btn-danger" type="button" onClick={remove}>
            Удалить статью
          </button>
        </div>
      </form>
    </>
  );
}

export function SettingsForm({
  settings,
  photo,
}: {
  settings: Record<string, string>;
  photo: { id: number; name: string } | null;
}) {
  const [site, setSite] = useState({
    site_title: settings.site_title ?? "",
    site_subtitle: settings.site_subtitle ?? "",
    about_title: settings.about_title ?? "",
    about_text: settings.about_text ?? "",
    public_base_url: settings.public_base_url ?? "",
  });
  const [photoId, setPhotoId] = useState<number | null>(photo?.id ?? null);
  const [photoName, setPhotoName] = useState<string | null>(photo?.name ?? null);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [repeatPassword, setRepeatPassword] = useState("");
  const [message, setMessage] = useState<Message | null>(null);
  const [passMessage, setPassMessage] = useState<Message | null>(null);
  const [busy, setBusy] = useState(false);

  function update(key: keyof typeof site, value: string) {
    setSite((prev) => ({ ...prev, [key]: value }));
  }

  async function saveSite(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMessage(null);
    const r = await callApi("/api/admin/settings", "PUT", {
      values: { ...site, about_photo_file_id: photoId ? String(photoId) : "" },
    });
    setBusy(false);
    setMessage(r.ok ? { kind: "ok", text: "Настройки сохранены." } : { kind: "error", text: r.error });
  }

  async function changePassword(e: FormEvent) {
    e.preventDefault();
    setPassMessage(null);
    if (newPassword.length < 6) {
      setPassMessage({ kind: "error", text: "Новый пароль должен быть не короче 6 символов." });
      return;
    }
    if (newPassword !== repeatPassword) {
      setPassMessage({ kind: "error", text: "Новый пароль и повтор не совпадают." });
      return;
    }
    setBusy(true);
    const r = await callApi("/api/admin/settings", "PUT", { currentPassword, newPassword });
    setBusy(false);
    if (r.ok) {
      setCurrentPassword("");
      setNewPassword("");
      setRepeatPassword("");
      setPassMessage({ kind: "ok", text: "Пароль изменён. Запомните новый пароль." });
    } else {
      setPassMessage({ kind: "error", text: r.error });
    }
  }

  return (
    <>
      <h1 className="admin-title">Настройки</h1>
      <p className="admin-sub">Название сайта, текст страницы «О наставнике», адрес сайта для Тильды и пароль.</p>

      {message ? <Notice kind={message.kind}>{message.text}</Notice> : null}
      <form className="card" onSubmit={saveSite} style={{ marginBottom: 32 }}>
        <div className="field">
          <label htmlFor="site-title">Название сайта</label>
          <input id="site-title" type="text" maxLength={200} value={site.site_title} onChange={(e) => update("site_title", e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="site-subtitle">Описание на главной</label>
          <textarea id="site-subtitle" rows={3} value={site.site_subtitle} onChange={(e) => update("site_subtitle", e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="about-title">Заголовок страницы «О наставнике»</label>
          <input id="about-title" type="text" maxLength={200} value={site.about_title} onChange={(e) => update("about_title", e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="about-text">Текст «О наставнике»</label>
          <textarea id="about-text" rows={8} value={site.about_text} onChange={(e) => update("about_text", e.target.value)} />
          <span className="hint">{TEXT_HINT}</span>
        </div>
        <MediaPicker
          label="Фото наставника (необязательно)"
          allowed={["image"]}
          allowLink={false}
          value={{ fileId: photoId, externalUrl: "" }}
          fileName={photoName}
          onChange={(v, name) => {
            setPhotoId(v.fileId);
            if (name) setPhotoName(name);
          }}
        />
        {photoId ? (
          <button
            className="btn btn-sm"
            type="button"
            style={{ marginBottom: 16 }}
            onClick={() => {
              setPhotoId(null);
              setPhotoName(null);
            }}
          >
            Убрать фото
          </button>
        ) : null}
        <div className="field">
          <label htmlFor="public-url">Адрес сайта в интернете (для Тильды и GitHub)</label>
          <input id="public-url" type="url" placeholder="https://academy.example.ru" value={site.public_base_url} onChange={(e) => update("public_base_url", e.target.value)} />
          <span className="hint">
            Оставьте пустым, и адрес определится автоматически. Заполните, когда сайт будет опубликован на своём домене.
          </span>
        </div>
        <button className="btn btn-primary" type="submit" disabled={busy}>
          {busy ? "Сохраняем…" : "Сохранить настройки"}
        </button>
      </form>

      <h2 className="display" style={{ fontSize: 22, marginBottom: 14 }}>
        Смена пароля администратора
      </h2>
      {passMessage ? <Notice kind={passMessage.kind}>{passMessage.text}</Notice> : null}
      <form className="card" onSubmit={changePassword}>
        <div className="field">
          <label htmlFor="cur-pass">Текущий пароль</label>
          <input id="cur-pass" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
        </div>
        <div className="admin-grid two">
          <div className="field">
            <label htmlFor="new-pass">Новый пароль</label>
            <input id="new-pass" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="rep-pass">Повторите новый пароль</label>
            <input id="rep-pass" type="password" value={repeatPassword} onChange={(e) => setRepeatPassword(e.target.value)} />
          </div>
        </div>
        <button className="btn" type="submit" disabled={busy || !currentPassword || !newPassword}>
          Сменить пароль
        </button>
      </form>
    </>
  );
}
